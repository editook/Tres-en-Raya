package estrategia;

import tresenraya.Posicion;

public class Migi implements Estrategia {

  private int[][] board = new int[3][3];
  private Posicion marcar;

  @Override
  public Posicion hacerJugada() {
    Posicion respuesta = new Posicion(1,1);
    if(verificarFilaGanadora(0) ||  verificarFilaGanadora(1) || verificarFilaGanadora(2) ||
        verificarColumnaGanadora(0) || verificarColumnaGanadora(1) || verificarColumnaGanadora(2) ||
        verificarDiagonalesIzq() || verificarDiagonalesDer()){
      respuesta = marcar;
      if(this.board[respuesta.fila][respuesta.columna] != 0){
        boolean encontre = false;
        for(int i = 0; i < 3 && !encontre; i++){
          for(int j = 0; j < 3 && !encontre; j++){
            if(board[i][j] == 0){
              respuesta = new Posicion(i,j);
              encontre = true;
            }
          }
        }
      }
    }else{
      boolean encontre = false;
      for(int i = 0; i < 3 && !encontre; i++){
        for(int j = 0; j < 3 && !encontre; j++){
          if(board[i][j] == 0){
            respuesta = new Posicion(i,j);
            encontre = true;
          }
        }
      }
    }
    this.board[respuesta.fila][respuesta.columna] = 2;
    return respuesta;
  }

  @Override
  public void registrarJugadaContraria(Posicion posicion) {
    if (validaPosicion(posicion)){
      board[posicion.fila][posicion.columna] = 1;
    }
    else {
      System.err.println("Estrategia Posicion Invalida verificar 0 - 2");
    }
  }

  private boolean validaPosicion(Posicion posicion) {
    return posicion.fila >= 0 && posicion.fila <= 2 && posicion.columna >= 0 && posicion.columna <= 2;
  }

  @Override
  public void reiniciarJuego() {
    board = new int[3][3];
  }

  private boolean verificarFilaGanadora(int fila) {
    boolean encontre = false;
    if (this.board[fila][0] == 1 && this.board[fila][1] == 1){
      marcar = new Posicion(fila,2);
      encontre = true;
    }
    if (this.board[fila][1] == 1 && this.board[fila][2] == 1){
      marcar = new Posicion(fila,0);
      encontre = true;
    }
    if (this.board[fila][0]== 1 && this.board[fila][2] == 1){
      marcar = new Posicion(fila,1);
      encontre = true;
    }
    return encontre;
  }

  private boolean verificarColumnaGanadora(int columna) {
    boolean encontre = false;
    if (this.board[0][columna] == 1 && this.board[1][columna] == 1){
      marcar = new Posicion(2,columna);
      encontre = true;
    }
    if (this.board[1][columna] == 1 && this.board[2][columna] == 1){
      marcar = new Posicion(0,columna);
      encontre = true;
    }
    if (this.board[0][columna] == 1 && this.board[2][columna] == 1){
      marcar = new Posicion(1,columna);
      encontre = true;
    }
    return encontre;
  }

  private boolean verificarDiagonalesIzq() {
    boolean encontre = false;
    if (this.board[0][0] == 1 && this.board[1][1] == 1){
      marcar = new Posicion(2,2);
      encontre = true;
    }
    if (this.board[1][1] == 1 && this.board[2][2] == 1){
      marcar = new Posicion(0,0);
      encontre = true;
    }
    if (this.board[0][0] == 1 && this.board[2][2] == 1){
      marcar = new Posicion(1,1);
      encontre = true;
    }
    if(encontre && this.board[marcar.fila][marcar.columna] != 0)
      encontre = false;
    return encontre;
  }

  private boolean verificarDiagonalesDer() {
    boolean encontre = false;
    if (this.board[0][2] == 1 && this.board[1][1] == 1){
      marcar = new Posicion(2,0);
      encontre = true;
    }
    if (this.board[1][1] == 1 && this.board[2][0] == 1){
      marcar = new Posicion(0,2);
      encontre = true;
    }
    if (this.board[0][2] == 1 && this.board[2][0] == 1){
      marcar = new Posicion(1,1);
      encontre = true;
    }
    return encontre;
  }

}
