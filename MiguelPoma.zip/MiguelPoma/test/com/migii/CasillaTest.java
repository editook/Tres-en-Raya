package com.migii;

import org.junit.Before;
import org.junit.Test;
import tresenraya.migii.logicadenegocio.tablero.implemetations.Casilla;
import tresenraya.migii.logicadenegocio.tablero.implemetations.TipoFicha;

import static org.junit.Assert.*;

public class CasillaTest {

    private Casilla.Builder builder;

    @Before
    public void setup(){
        builder = new Casilla.Builder();
    }

    @Test
    public void testMiCasillaEstaVacia(){
        builder.posicion(0,0);
        boolean esta_vacia = builder.build().estaVacia();
        assertTrue(esta_vacia);
    }

    @Test
    public void testMiCasillaNoEstaVacia(){
        builder.posicion(0,0).ficha(TipoFicha.Cruz);
        boolean esta_vacia = builder.build().estaVacia();
        assertFalse(esta_vacia);
    }

    @Test
    public void testMiCasillaTieneCruz(){
        builder.posicion(0,0).ficha(TipoFicha.Cruz);
        TipoFicha ficha = builder.build().obtenerFicha();
        assertEquals(TipoFicha.Cruz,ficha);
    }

    @Test
    public void testMiCasillaTieneCirculo(){
        builder.posicion(0,0).ficha(TipoFicha.Circulo);
        TipoFicha ficha = builder.build().obtenerFicha();
        assertEquals(TipoFicha.Circulo,ficha);
    }

    @Test
    public void testCasillaDiferentesFicha(){
        builder.posicion(0,0).ficha(TipoFicha.Cruz);
        Casilla casilla1 = builder.build();
        builder.posicion(0,0).ficha(TipoFicha.Circulo);
        Casilla casilla2 = builder.build();
        boolean son_iguales = casilla1.equals(casilla2);
        assertFalse(son_iguales);
    }

    @Test
    public void testCasillaIgualesFicha(){
        builder.posicion(0,0).ficha(TipoFicha.Cruz);
        Casilla casilla1 = builder.build();
        Casilla casilla2 = builder.build();
        boolean son_iguales = casilla1.equals(casilla2);
        assertTrue(son_iguales);
    }



}