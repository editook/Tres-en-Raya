package com.migii;

import org.junit.Before;
import org.junit.Test;
import tresenraya.migii.logicadenegocio.reglas.implemetations.CasillaVacia;
import tresenraya.migii.logicadenegocio.reglas.implemetations.CasillaValida;
import tresenraya.migii.logicadenegocio.tablero.implemetations.Casilla;
import tresenraya.migii.logicadenegocio.tablero.implemetations.TableroCuadrado;
import tresenraya.migii.logicadenegocio.tablero.implemetations.TipoFicha;
import tresenraya.migii.logicadenegocio.tablero.interfaces.ITablero;

import static org.junit.Assert.*;

public class TableroCuadradoTest {

  private ITablero tablero;
  private Casilla.Builder builder;

  @Before
  public void setup(){
      tablero = new TableroCuadrado(3,3);
      builder = new Casilla.Builder();
  }

  @Test
  public void testMarcarCasillaVacia(){
      Casilla casilla = builder.posicion(0,0).ficha(TipoFicha.Cruz).build();
      CasillaVacia casillaVacia = new CasillaVacia(tablero);
      casillaVacia.setChange(casilla);
      boolean se_puede = casillaVacia.cumple();
      assertTrue(se_puede);
  }

  @Test
  public void testMarcarCasillaLlena(){
      Casilla casilla = builder.posicion(0,0).ficha(TipoFicha.Cruz).build();
      CasillaVacia casillaVacia = new CasillaVacia(tablero);
      tablero.marcarCasilla(casilla);
      casillaVacia.setChange(casilla);
      boolean se_puede = casillaVacia.cumple();
      assertFalse(se_puede);
  }

  @Test
  public void testMarcarCasillaInvalida(){
      builder.posicion(-1,-1).ficha(TipoFicha.Cruz);
      Casilla casilla = builder.build();
      CasillaValida casillaValida = new CasillaValida();
      casillaValida.setChange(tablero, casilla);
      boolean se_puede = casillaValida.cumple();
      assertFalse(se_puede);
  }

  @Test(expected = ArrayIndexOutOfBoundsException.class)
  public void testSeDebeComprabarCasillaAntesMarcar(){
      builder.posicion(3,3).ficha(TipoFicha.Cruz);
      Casilla casilla = builder.build();
      tablero.marcarCasilla(casilla);
  }

}