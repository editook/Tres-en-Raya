package com.migii;

import org.junit.Before;
import org.junit.Test;
import tresenraya.Posicion;
import tresenraya.migii.logicadenegocio.juego.implemetations.TresEnRaya;

import static org.junit.Assert.*;

public class TresEnRayaTest {

  TresEnRaya tresEnRaya;

  @Before
  public void setup(){
      tresEnRaya = new TresEnRaya();
  }

  @Test
  public void testGanadorFichaCruz(){
      tresEnRaya.hacerJugadaX(new Posicion(0,0));
      tresEnRaya.hacerJugadaO(new Posicion(0,1));
      tresEnRaya.hacerJugadaX(new Posicion(1,0));
      tresEnRaya.hacerJugadaO(new Posicion(0,2));
      tresEnRaya.hacerJugadaX(new Posicion(2,0));
      char resultado = tresEnRaya.obtenerGanador();
      assertEquals('X',resultado);
  }

  @Test
  public void testGanadorFichaCirculo(){
    tresEnRaya.hacerJugadaX(new Posicion(2,2));
    tresEnRaya.hacerJugadaO(new Posicion(0,0));
    tresEnRaya.hacerJugadaX(new Posicion(1,0));
    tresEnRaya.hacerJugadaO(new Posicion(0,1));
    tresEnRaya.hacerJugadaX(new Posicion(1,1));
    tresEnRaya.hacerJugadaO(new Posicion(0,2));
    char resultado = tresEnRaya.obtenerGanador();
    assertEquals('O',resultado);
  }

  @Test
  public void testJuegoTerminoEmpate(){
    tresEnRaya.hacerJugadaX(new Posicion(0,0));
    tresEnRaya.hacerJugadaO(new Posicion(0,1));
    tresEnRaya.hacerJugadaX(new Posicion(0,2));
    tresEnRaya.hacerJugadaO(new Posicion(1,1));
    tresEnRaya.hacerJugadaX(new Posicion(1,0));
    tresEnRaya.hacerJugadaO(new Posicion(1,2));
    tresEnRaya.hacerJugadaX(new Posicion(2,1));
    tresEnRaya.hacerJugadaO(new Posicion(2,0));
    tresEnRaya.hacerJugadaX(new Posicion(2,2));
    char resultado = tresEnRaya.obtenerGanador();
    assertEquals('\0',resultado);
  }

}