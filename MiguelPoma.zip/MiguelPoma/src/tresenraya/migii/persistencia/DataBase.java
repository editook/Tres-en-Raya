package tresenraya.migii.persistencia;

import tresenraya.migii.library.Utils;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class DataBase {

  private ArrayList<ModelJugador> jugadores = new ArrayList<>();
  private static DataBase instance = null;
  private File database = new File(Utils.DIRECCION_DATABASE);

  private DataBase() {
    loadFromFile();
  }

  public static DataBase getInstance() {
    if(instance == null) {
      instance = new DataBase();
    }
    return instance;
  }

  public void addJugador(ModelJugador modelJugador) {
    jugadores.add(modelJugador);
    Collections.sort(jugadores);
  }

  public List<ModelJugador> getJugadores() {
    return jugadores;
  }

  public void saveToFile(File file) throws IOException {
    FileOutputStream fos = new FileOutputStream(file);
    ObjectOutputStream oos = new ObjectOutputStream(fos);
    oos.writeObject(jugadores.toArray(new ModelJugador[jugadores.size()]));
    oos.close();
  }

  private void loadFromFile(File file) throws IOException {
    FileInputStream fis = new FileInputStream(file);
    ObjectInputStream ois = new ObjectInputStream(fis);
    try {
      ModelJugador[] modelJugadors = (ModelJugador[])ois.readObject();
      Arrays.sort(modelJugadors);
      jugadores.clear();
      jugadores.addAll(Arrays.asList(modelJugadors));
      ois.close();
    } catch (Exception e) {
      FileOutputStream fos = new FileOutputStream(file);
      ObjectOutputStream oos = new ObjectOutputStream(fos);
      oos.writeObject(jugadores.toArray(new ModelJugador[jugadores.size()]));
      oos.close();
    }

  }

  public void removePlayer(String nombre) {
    boolean eliminado = false;
    for(int i = 0; i < jugadores.size() && !eliminado; i++){
     if(jugadores.get(i).getNombre().equals(nombre)){
       jugadores.remove(i);
       eliminado = true;
     }
    }
  }

  public boolean existePlayer(String nombre) {
    boolean existe = false;
    for(int i = 0; i < jugadores.size() && !existe; i++){
      if(jugadores.get(i).getNombre().equals(nombre)){
        existe = true;
      }
    }
    return existe;
  }

  public ModelJugador getJugador(String nombre) {
    ModelJugador modelJugador = null;
    boolean existe = false;
    for(int i = 0; i < jugadores.size() && !existe; i++){
      if(jugadores.get(i).getNombre().equals(nombre)){
        modelJugador = jugadores.get(i);
        existe = true;
      }
    }
    return modelJugador;
  }

  public void limpiar() {
    jugadores.clear();
  }

  private void loadFromFile()  {
    try {
      loadFromFile(database);
    } catch (IOException e) {
      System.err.println("Direccion Incorrecta del Archivo Base de Datos");
    }
  }

}
