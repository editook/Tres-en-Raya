package tresenraya.migii.persistencia;

import tresenraya.migii.logicadenegocio.tablero.implemetations.TipoFicha;
import java.io.Serializable;

public class ModelJugador implements Serializable, Comparable<ModelJugador> {

  private String nombre;
  private int juegosGanados;
  private TipoFicha ficha;

  public ModelJugador(String nombre){
    this.nombre = nombre;
    juegosGanados = 0;
  }

  public void increaseVictories() {
    juegosGanados++;
  }

  public String getNombre() {
    return nombre;
  }

  public int getJuegosGanados() {
    return juegosGanados;
  }

  public TipoFicha getFicha() {
    return ficha;
  }

  public void setFicha(TipoFicha ficha) {
    this.ficha = ficha;
  }

  public void setNombre(String nombre) {
    this.nombre = nombre;
  }

  public void setJuegosGanados(int juegosGanados) {
    this.juegosGanados = juegosGanados;
  }

  @Override
  public int compareTo(ModelJugador modelJugador) {
    int answer;
    if(this.juegosGanados > modelJugador.juegosGanados){
      answer = -1;
    }else if(this.juegosGanados < modelJugador.juegosGanados){
      answer = 1;
    }else answer = 0;
    return answer;
  }

}
