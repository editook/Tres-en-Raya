package tresenraya.migii.userinterface.events;

public enum Event {
  SearchAlgorithm,
  MarcarTablero,
  NuevoJugador,
  Joystick,
  MostrarFormDialogPlayer,
  OcultarFormDialogPlayer,
  NewGame,
  About,
  Exit,
  TablaPosiciones,
  Url
}
