package tresenraya.migii.userinterface.events;

import java.awt.event.ActionEvent;

public class AboutEvent extends EventTresEnRaya {

  @Override
  public void actionPerformed(ActionEvent actionEvent) {
    notifyAbout();
  }

}
