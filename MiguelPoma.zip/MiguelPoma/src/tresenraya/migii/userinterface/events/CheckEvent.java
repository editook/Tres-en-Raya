package tresenraya.migii.userinterface.events;

import tresenraya.Posicion;
import java.awt.event.ActionEvent;
import tresenraya.migii.library.TransformacionGeometrica;

public class CheckEvent extends EventTresEnRaya {

  @Override
  public void actionPerformed(ActionEvent actionEvent) {
    String btn = actionEvent.getActionCommand();
    Posicion posicion;
    if (btn.matches("[0-9]*")){
      posicion = TransformacionGeometrica.transformar2D(Integer.parseInt( btn ) - 1);
    }
    else
      posicion = null;
    notifyNewCheck(posicion);
  }

}
