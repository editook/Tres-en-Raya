package tresenraya.migii.userinterface.events;

import java.awt.event.ActionEvent;

public class UrlEvent extends EventTresEnRaya {

  @Override
  public void actionPerformed(ActionEvent actionEvent) {
    notifyChangeView(actionEvent.getActionCommand());
  }
}
