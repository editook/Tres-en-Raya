package tresenraya.migii.userinterface.events;

import java.awt.event.ActionListener;
import java.util.HashMap;

public class EventManager {

  private static EventManager instance = null;
  private HashMap<Event,EventTresEnRaya> actionListeners;

  private EventManager() {
    actionListeners = new HashMap<>();
  }

  public static EventManager getInstance() {
    if(instance == null) {
      instance = new EventManager();
    }
    return instance;
  }

  public void addListener(Event nombre, EventTresEnRaya var1) {
    if (var1 == null) {
      throw new NullPointerException();
    } else {
      if (!this.actionListeners.containsKey(nombre)) {
        this.actionListeners.put(nombre,var1);
      }else{
        System.err.println("Event repetido");
      }
    }
  }

  public void deleteListener(Event nombre) {
    if (this.actionListeners.containsKey(nombre)) {
      this.actionListeners.remove(nombre);
    }
  }

  public ActionListener getListener(Event nombre){
    ActionListener actionListener = null;
    if (this.actionListeners.containsKey(nombre)) {
      actionListener = this.actionListeners.get(nombre);
    }
    return actionListener;
  }

  public HashMap<Event, EventTresEnRaya> getListeners() {
    return actionListeners;
  }

  public void clear() {
    actionListeners.clear();
  }
}
