package tresenraya.migii.userinterface.events;

import tresenraya.migii.listener.Anuncio;
import java.awt.event.ActionListener;

public abstract class EventTresEnRaya extends Anuncio implements ActionListener {

}
