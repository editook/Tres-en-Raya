package tresenraya.migii.userinterface.events;

import java.awt.event.ActionEvent;

public class JoystickEvent extends EventTresEnRaya {

  @Override
  public void actionPerformed(ActionEvent actionEvent) {
    notifyEventJoystick(actionEvent.getActionCommand());
  }

}
