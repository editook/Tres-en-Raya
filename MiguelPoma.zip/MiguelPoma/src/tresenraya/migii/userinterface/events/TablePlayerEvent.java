package tresenraya.migii.userinterface.events;

import java.awt.event.ActionEvent;

public class TablePlayerEvent extends EventTresEnRaya {

  @Override
  public void actionPerformed(ActionEvent actionEvent) {
    notifyTablePlayer();
  }
}
