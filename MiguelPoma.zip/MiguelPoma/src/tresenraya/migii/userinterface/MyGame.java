package tresenraya.migii.userinterface;

import tresenraya.migii.userinterface.components.formplayer.FormComponent;
import tresenraya.migii.userinterface.components.NotificadorComponent;
import tresenraya.migii.userinterface.components.joystick.JoystickComponent;
import tresenraya.migii.userinterface.components.tableplayer.TablePlayerComponent;
import tresenraya.migii.userinterface.components.boardgame.BoardPaint;
import tresenraya.migii.userinterface.components.boardgame.TableroComponent;
import tresenraya.migii.listener.componentmanager.FrameManager;
import tresenraya.migii.logicadenegocio.juego.implemetations.TresEnRaya;
import tresenraya.migii.userinterface.components.boardgame.Tablero;
import tresenraya.migii.userinterface.components.menu.MenuComponent;
import java.awt.BorderLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JFrame;
import javax.swing.UIManager;
import javax.swing.UIManager.LookAndFeelInfo;
/**
 * @author: Adam Taylor (D3M0L1$3®)
 * @version: 1.0.1.3
 * @release date: 01/29/2010
 * This is a simple Tic-tac-toe game written in Java
 * with some medeokre AI.
 * You go first,
 * can start a new game while in-game, or at the end of game
 * and it asks
 * @Project Page:https://sourceforge.net/projects/tictactoe-javab/
 * @My Page: http://kickbanned.wordpress.com/
 * */

public class MyGame extends JFrame {

  private TresEnRaya tresEnRaya;
  private FrameManager frameManagerTresEnRaya;
  private BoardPaint boardGUI;
  private FormComponent formComponent;

  public MyGame(TresEnRaya tresEnRaya) {
    this.tresEnRaya = tresEnRaya;
    lookAndFeel();
    makeComponentManager();
    initComponents();
  }

  private void makeComponentManager() {
    frameManagerTresEnRaya = new FrameManager(this, tresEnRaya);
  }

  private void initComponents() {
    getContentPane().setLayout(new BorderLayout());
    setResizable( true );
    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent evt) {
        exit();
      }
    });
  }

   private void lookAndFeel() {
    try {
      for (LookAndFeelInfo info : UIManager.getInstalledLookAndFeels())
        if ("Nimbus".equals(info.getName())) {
          UIManager.setLookAndFeel(info.getClassName());
          break;
        }
    } catch (Exception e) {
      // If Nimbus is not available, you can set the GUI to another look and feel.
    }
  }

  private void exit() {
    System.exit( 0 );
  }

  public TableroComponent getTablero(Tablero tablero) {
    TableroComponent tableroComponent = null;
    switch (tablero){
      case Default:
        tableroComponent = null;
        break;
      case Arcade:
        tableroComponent = this.boardGUI;
        break;
      case Moderno:
        tableroComponent = this.boardGUI;
        break;
    }
    return tableroComponent;
  }

  public MenuComponent getMenuComponent() {
    return null;
  }

  public TablePlayerComponent getTablePlayer() {
    return null;
  }

  public NotificadorComponent getNotificadorComponent() {
    return null;
  }

  public FormComponent getFormComponent() {
    return formComponent;
  }

  public JoystickComponent getJoystick() {
    return null;
  }
}

