package tresenraya.migii.userinterface.components.boardgame;

import tresenraya.migii.library.TransformacionGeometrica;
import tresenraya.migii.library.Utils;
import tresenraya.Posicion;
import tresenraya.migii.logicadenegocio.tablero.implemetations.TipoFicha;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.RoundRectangle2D;
import javax.swing.BorderFactory;
import javax.swing.border.Border;

public class BoardPaint extends TableroComponent {

  private Graphics2D g2;
  private Font textoFormato = new Font("Comic Sans MS", Font.BOLD, 50 );
  private Posicion centroCasilla, puntero;
  private String [][] board ;
  private String figura;
  private String ficha = "º";
  private boolean mostrarPuntero;

  public BoardPaint(String figura){
    this.figura = figura;
    this.mostrarPuntero = false;
    centroCasilla = new Posicion(Utils.CENTER_FIRST_CELL_X+70,Utils.CENTER_FIRST_CELL_Y+100);
    puntero = new Posicion(centroCasilla.fila,centroCasilla.columna);
    board = new String[Utils.ROWS_TRES_EN_RAYA][Utils.COLUMNS_TRES_EN_RAYA];
    setNewGame();
  }

  public void mostrarPuntero(boolean estado){
    this.mostrarPuntero = estado;
  }

  private void initTablero() {
    g2.setColor(Color.white);
    g2.fillRect(0, 0, getWidth(), getHeight());
    g2.setColor(Color.black);

    g2.fill(new RoundRectangle2D.Double(Utils.CENTER_FIRST_CELL_X+40,Utils.CENTER_FIRST_CELL_Y+120
        ,300, 7, 10, 20));
    g2.fill(new RoundRectangle2D.Double(Utils.CENTER_FIRST_CELL_X+40, Utils.CENTER_FIRST_CELL_Y+Utils.DISTACIA_CASILLA+120
        ,300, 7, 10, 20));
    g2.fill(new RoundRectangle2D.Double(Utils.CENTER_FIRST_CELL_X+130,Utils.CENTER_FIRST_CELL_Y+28
        ,7, 300, 10, 20));
    g2.fill(new RoundRectangle2D.Double(Utils.CENTER_FIRST_CELL_X+130+Utils.DISTACIA_CASILLA,Utils.CENTER_FIRST_CELL_Y+28
        ,7, 300, 10, 20));
  }

  @Override
  public void drawCasilla(Posicion posicion, String cadena) {
    board[posicion.fila][posicion.columna] = cadena;
    repaint();
  }

  public void setNewGame() {
    for (int i = 0; i < board.length; i++){
      for (int j = 0; j < board[0].length; j++){
        board[i][j] = figura;
      }
    }
    repaint();
  }

  @Override
  public void setNewTablero(String tablero) {
    int r = 0;
    for (int i = 0; i < board.length; i++){
      for (int j = 0; j < board[0].length; j++){
        if(tablero.charAt(r) == ' '){
          board[i][j] = ""+figura;
        }else
          board[i][j] = ""+tablero.charAt(r);
        r++;
      }
    }
    repaint();
  }

  public void  setBorderPanel(String title){
    Border innerBorder = BorderFactory.createTitledBorder(title);
    Border outerBorder = BorderFactory.createEmptyBorder(5,5,5,5);
    setBorder(BorderFactory.createCompoundBorder(outerBorder,innerBorder));
  }

  @Override
  public void paintComponent(Graphics g) {
    g2 = (Graphics2D)g;
    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
    g2.setFont(textoFormato);
    initTablero();
    g2.setColor(Color.green);

    for (int i = 0; i < board.length; i++)
      for (int j = 0; j < board[0].length; j++) {
        Posicion escalar = TransformacionGeometrica.escalar(j, i, Utils.DISTACIA_CASILLA);
        Color paint = board[i][j].equals(TipoFicha.Cruz.toString()) ? Color.red :
            board[i][j].equals(TipoFicha.Circulo.toString()) ? Color.blue : Color.DARK_GRAY;
        g2.setColor(paint);
        g2.drawString(board[i][j], centroCasilla.fila + escalar.fila,
            centroCasilla.columna + escalar.columna);
      }

      if(mostrarPuntero){
        g2.setColor(Color.CYAN);
        g2.drawString(ficha,puntero.fila,puntero.columna);
      }
  }

  void setBoard(String tablero) {
    for(int i = 0; i < 9; i++){
      Posicion posicion = TransformacionGeometrica.transformar2D(i);
      board[posicion.fila][posicion.columna] = ""+tablero.charAt(i);
    }
  }

  @Override
  public void drawPuntero(Posicion posicion, String cadena) {
    this.puntero.fila = centroCasilla.fila+posicion.fila;
    this.puntero.columna = centroCasilla.columna+posicion.columna;
    this.ficha = cadena;
    repaint();
  }

}
