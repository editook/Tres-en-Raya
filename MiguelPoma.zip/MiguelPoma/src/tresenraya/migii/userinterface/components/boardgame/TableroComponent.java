package tresenraya.migii.userinterface.components.boardgame;

import tresenraya.Posicion;
import tresenraya.migii.listener.interfaces.IEventBoardGame;
import javax.swing.JPanel;

public abstract class TableroComponent extends JPanel implements IEventBoardGame {
  public abstract void drawPuntero(Posicion posicion, String cadena);
  public abstract void setBorderPanel(String s);
  public abstract void setNewTablero(String board);
}