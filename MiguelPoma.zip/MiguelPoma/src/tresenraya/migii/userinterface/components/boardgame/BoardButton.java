package tresenraya.migii.userinterface.components.boardgame;

import tresenraya.Posicion;
import tresenraya.migii.userinterface.events.Event;
import tresenraya.migii.library.TransformacionGeometrica;
import tresenraya.migii.userinterface.events.EventManager;
import java.awt.GridLayout;

public class BoardButton extends TableroComponent {

  private CasillaGUI button[];
  private EventManager listener;

  public BoardButton(){
    listener = EventManager.getInstance();
    initTablero();
  }

  private void initTablero() {
    setLayout( new GridLayout( 3, 3, 1, 1 ) );
    button = new CasillaGUI[ 10 ];
    for ( int i = 1; i < 10; i++ ) {
      button[i] = new CasillaGUI(i);
      button[i].addActionListener(listener.getListener(Event.MarcarTablero));
      add( button[ i ] );
    }
  }

  @Override
  public void setNewGame() {
    for ( int j = 1; j < 10; j++ ) {
      button[ j ].setText( "" );
    }
  }

  @Override
  public void setNewTablero(String tablero) {
    for (int i = 1; i < 10; i++){
      button[ i ].setText( ""+tablero.charAt(i-1) );
    }
  }

  @Override
  public void drawCasilla(Posicion posicion, String cadena) {
    int index = TransformacionGeometrica.transformar1D(posicion.fila,posicion.columna) + 1;
    button[ index ].setText( cadena );
  }

  @Override
  public void drawPuntero(Posicion posicion, String cadena) {

  }

  @Override
  public void setBorderPanel(String s) {

  }

}
