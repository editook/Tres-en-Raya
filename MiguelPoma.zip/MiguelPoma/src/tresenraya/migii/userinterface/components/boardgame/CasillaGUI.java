package tresenraya.migii.userinterface.components.boardgame;

import java.awt.Font;
import java.awt.Dimension;
import javax.swing.JButton;

 class CasillaGUI extends JButton {

   CasillaGUI(int id){
    initCasilla(id);
  }

  private void initCasilla(int id) {
    setFocusPainted( false );
    setActionCommand( Integer.toString( id ) );
    setFont( new Font( "Dialog", Font.PLAIN, 48 ) );
    setPreferredSize( new Dimension( 100, 100 ) );
    setToolTipText( "Click to make your move" );
  }

}
