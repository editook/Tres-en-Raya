package tresenraya.migii.userinterface.components.boardgame;

public enum Tablero {
  Default{
    @Override
    public String toString(){
      return "Default";
    }
  },Arcade
  {
    @Override
    public String toString(){
      return "Clasico";
    }
  }, Moderno{
    @Override
    public String toString(){
      return "Moderno";
    }
  }
}
