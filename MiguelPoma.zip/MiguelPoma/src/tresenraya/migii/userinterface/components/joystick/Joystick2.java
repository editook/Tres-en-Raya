package tresenraya.migii.userinterface.components.joystick;

import tresenraya.Posicion;
import tresenraya.migii.listener.componentmanager.JoystickManager;
import tresenraya.migii.logicadenegocio.jugador.implemetations.Bot;
import tresenraya.migii.persistencia.ModelJugador;
import tresenraya.migii.userinterface.BgBorder;
import tresenraya.migii.userinterface.components.formplayer.EventForm;
import tresenraya.migii.userinterface.events.Event;
import tresenraya.migii.userinterface.events.EventManager;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;

public class Joystick2 extends JoystickComponent {

  private EventManager eventManager = EventManager.getInstance();
  private JButton equis;
  private JButton circulo;
  private JoystickManager joystickManager;
  private Bot botX;
  private Bot botO;
  private boolean turno;

  public Joystick2(JoystickManager joystickManager, Bot botX, Bot botO){
    this.botX = botX;
    this.botO = botO;
    this.turno = true;
    this.joystickManager = joystickManager;
    initComponents();
  }

  private void initComponents() {
    int height = -1;
    int width = 30;
    ImageIcon iconEquis =  new ImageIcon("resource/equis.png");
    ImageIcon iconCirculo =  new ImageIcon("resource/circuloazul.png");
    setLayout(new GridBagLayout());

    GridBagConstraints gc = new GridBagConstraints();
    gc.gridy = 0;
    setSize(400, 300);

    equis = new JButton();
    circulo = new JButton();
    equis.setActionCommand("equis");
    circulo.setActionCommand("circulo");

    equis.setIcon(new ImageIcon( iconEquis.getImage().getScaledInstance(width,height,Image.SCALE_DEFAULT)) );
    equis.addActionListener(eventManager.getListener(Event.MarcarTablero));
    circulo.setIcon(new ImageIcon( iconCirculo.getImage().getScaledInstance(width,height,Image.SCALE_DEFAULT)) );
    circulo.addActionListener(eventManager.getListener(Event.MarcarTablero));
    gc.gridy = 0;
    gc.weightx = 2;
    gc.weighty = 2;
    gc.fill = GridBagConstraints.NONE;
    gc.gridx = 0;
    add(circulo, gc);
    gc.gridx = 1;
    add(equis, gc);

    equis.setEnabled(false);
    circulo.setEnabled(false);
    try {
      String path = "resource/joystick2.jpg";
      BgBorder borde = new BgBorder(ImageIO.read(new File(path)) ) ;
      setBorder(borde);
    } catch (IOException e) {
      System.err.println(e.getMessage());
    }
  }

  @Override
  public void jugar(Posicion posicion) {
    boolean jugadaCorrecta;
    if(jugadoresCargados()){
      if(turno){
        posicion = this.botX.hacerJugada();
        jugadaCorrecta = this.joystickManager.jugarX(posicion);
        if(jugadaCorrecta){
          this.botO.registrarJugada(posicion);
          turno = !turno;
          this.equis.setEnabled(false);
          this.circulo.setEnabled(true);
        }
      }else{
        posicion = this.botO.hacerJugada();
        jugadaCorrecta = this.joystickManager.jugarO(posicion);
        if(jugadaCorrecta){
          this.botX.registrarJugada(posicion);
          turno = !turno;
          this.equis.setEnabled(true);
          this.circulo.setEnabled(false);
        }
      }
    }
  }

  @Override
  public Posicion updateCasilla(String actionCommand) {
    return null;
  }

  @Override
  public ModelJugador crearJugadorX(EventForm eventForm) {
    if(eventForm.getMyClass() != null) {
      this.botX.activar(true);
      this.botX.cambiarIngenio(eventForm.getMyClass());
      if(this.botO.estaActivo()){
        this.equis.setEnabled(true);
      }
    }
    return new ModelJugador(eventForm.getNombre());
  }

  @Override
  public ModelJugador crearJugadorO(EventForm eventForm) {
    if(eventForm.getMyClass() != null) {
      this.botO.activar(true);
      this.botO.cambiarIngenio(eventForm.getMyClass());
      if(this.botX.estaActivo()){
        this.equis.setEnabled(true);
      }
    }
    return new ModelJugador(eventForm.getNombre());
  }

  @Override
  public boolean jugadoresCargados() {
    return this.botX.estaActivo() && this.botO.estaActivo();
  }

}
