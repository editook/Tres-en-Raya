package tresenraya.migii.userinterface.components.joystick;

public interface ModoJuego {
  void jugar();
}
