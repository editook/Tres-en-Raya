package tresenraya.migii.userinterface.components.joystick;

public enum  CommandJoystick {
  Up{
    @Override
    public String toString(){
      return "Up";
    }
  },
  Down{
    @Override
    public String toString(){
      return "Down";
    }
  },
  Left{
    @Override
    public String toString(){
      return "Left";
    }
  },
  Right{
    @Override
    public String toString(){
      return "Right";
    }
  }
}
