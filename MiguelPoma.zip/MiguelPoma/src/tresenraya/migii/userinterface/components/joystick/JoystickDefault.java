package tresenraya.migii.userinterface.components.joystick;

import tresenraya.Posicion;
import tresenraya.migii.listener.componentmanager.JoystickManager;
import tresenraya.migii.logicadenegocio.jugador.implemetations.Bot;
import tresenraya.migii.persistencia.ModelJugador;
import tresenraya.migii.userinterface.components.formplayer.EventForm;

public class JoystickDefault extends JoystickComponent{

  private JoystickManager joystickManager;
  private Bot botO;
  private ModelJugador dataX;
  private ModelJugador dataO;

  public JoystickDefault(JoystickManager joystickManager, Bot botO){
    this.botO = botO;
    this.joystickManager = joystickManager;
  }

  @Override
  public void jugar(Posicion posicion) {
    boolean jugadaCorrecta = this.joystickManager.jugarX(posicion);
    if(jugadaCorrecta){
      this.botO.registrarJugada(posicion);
      this.joystickManager.jugarO(this.botO.hacerJugada());
    }
  }

  @Override
  public Posicion updateCasilla(String actionCommand) {
    return null;
  }

  @Override
  public ModelJugador crearJugadorX(EventForm eventForm) {
    return this.dataX = new ModelJugador(eventForm.getNombre());
  }

  @Override
  public ModelJugador crearJugadorO(EventForm eventForm) {
    return this.dataO = new ModelJugador(eventForm.getNombre());
  }

  @Override
  public boolean jugadoresCargados() {
    return false;
  }

}
