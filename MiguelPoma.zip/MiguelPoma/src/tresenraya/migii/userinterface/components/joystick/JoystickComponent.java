package tresenraya.migii.userinterface.components.joystick;

import javax.swing.JPanel;
import tresenraya.Posicion;
import tresenraya.migii.persistencia.ModelJugador;
import tresenraya.migii.userinterface.components.formplayer.EventForm;

public abstract class JoystickComponent extends JPanel {

  public abstract void jugar(Posicion posicion);
  
  public abstract Posicion updateCasilla(String actionCommand);

  public abstract ModelJugador crearJugadorX(EventForm eventForm);

  public abstract ModelJugador crearJugadorO(EventForm eventForm);

  public abstract boolean jugadoresCargados();


}
