package tresenraya.migii.userinterface.components.joystick;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import tresenraya.Posicion;
import tresenraya.migii.library.TransformacionGeometrica;
import tresenraya.migii.library.Utils;
import tresenraya.migii.listener.componentmanager.JoystickManager;
import tresenraya.migii.logicadenegocio.jugador.implemetations.Bot;
import tresenraya.migii.persistencia.ModelJugador;
import tresenraya.migii.userinterface.BgBorder;
import tresenraya.migii.userinterface.components.formplayer.EventForm;
import tresenraya.migii.userinterface.events.Event;
import tresenraya.migii.userinterface.events.EventManager;

public class JoystickArcade extends JoystickComponent {

  private EventManager eventManager = EventManager.getInstance();
  private Posicion puntero;
  private Bot botX;
  private Bot botO;
  private JoystickManager joystickManager;

  public JoystickArcade(JoystickManager joystickManager, Bot botX, Bot botO){
    puntero = new Posicion(0,0);
    this.botX = botX;
    this.botO = botO;
    this.joystickManager = joystickManager;
    initComponents();
  }

  @Override
  public void jugar(Posicion posicion) {
    posicion = puntero;
    boolean jugadaCorrecta;
    if(this.botX.estaActivo()){
      posicion = this.botX.hacerJugada();
      jugadaCorrecta = this.joystickManager.jugarX(posicion);
    }else {
      jugadaCorrecta = this.joystickManager.jugarX(posicion);
    }
    if(jugadaCorrecta){
      this.botO.registrarJugada(posicion);
      this.joystickManager.jugarO(this.botO.hacerJugada());
    }
  }

  @Override
  public ModelJugador crearJugadorX(EventForm eventForm) {
    if(eventForm.getMyClass() != null) {
      this.botX.activar(true);
      this.botX.cambiarIngenio(eventForm.getMyClass());
    }
    return new ModelJugador(eventForm.getNombre());
  }

  @Override
  public ModelJugador crearJugadorO(EventForm eventForm) {
    return new ModelJugador(eventForm.getNombre());
  }

  @Override
  public boolean jugadoresCargados() {
    return false;
  }

  private void initComponents() {
    int height = -1;
    int width = 30;
    ImageIcon iconCheck =  new ImageIcon("resource/equis.png");
    ImageIcon iconUp =  new ImageIcon("resource/up.png");
    ImageIcon iconLeft =  new ImageIcon("resource/left.png");
    ImageIcon iconRight =  new ImageIcon("resource/right.png");
    ImageIcon iconDown =  new ImageIcon("resource/down.png");
    setLayout(new GridBagLayout());

    GridBagConstraints gc = new GridBagConstraints();
    gc.gridy = 0;
    setSize(400, 300);

    JButton check = new JButton();
    JButton left = new JButton();
    JButton right = new JButton();
    JButton up = new JButton();
    JButton down = new JButton();

    left.setActionCommand(CommandJoystick.Left.toString());
    right.setActionCommand(CommandJoystick.Right.toString());
    up.setActionCommand(CommandJoystick.Up.toString());
    down.setActionCommand(CommandJoystick.Down.toString());

    check.setIcon(new ImageIcon( iconCheck.getImage().getScaledInstance(width,height,Image.SCALE_DEFAULT)) );
    check.setActionCommand("JoystickComponent");
    up.setIcon(new ImageIcon( iconUp.getImage().getScaledInstance(width,height,Image.SCALE_DEFAULT)) );
    down.setIcon(new ImageIcon( iconDown.getImage().getScaledInstance(width,height,Image.SCALE_DEFAULT)) );
    left.setIcon(new ImageIcon( iconLeft.getImage().getScaledInstance(width,height,Image.SCALE_DEFAULT)) );
    right.setIcon(new ImageIcon( iconRight.getImage().getScaledInstance(width,height,Image.SCALE_DEFAULT)) );

    check.addActionListener(eventManager.getListener(Event.MarcarTablero));
    left.addActionListener(eventManager.getListener(Event.Joystick));
    right.addActionListener(eventManager.getListener(Event.Joystick));
    up.addActionListener(eventManager.getListener(Event.Joystick));
    down.addActionListener(eventManager.getListener(Event.Joystick));

    gc.gridy = 0;
    gc.weightx = 1;
    gc.weighty = 1;
    gc.fill = GridBagConstraints.NONE;
    gc.gridx = 1;
    add(up, gc);
    gc.gridy++;
    //NextRow
    gc.weightx = 1;
    gc.weighty = 1;
    gc.fill = GridBagConstraints.NONE;
    gc.gridx = 0;
    add(left, gc);
    gc.gridx++;
    add(check, gc);
    gc.gridx++;
    add(right, gc);
    gc.gridy++;
    //NextRow
    gc.weightx = 1;
    gc.weighty = 1;
    gc.fill = GridBagConstraints.NONE;
    gc.gridx = 1;
    add(down, gc);
    gc.gridy++;
    try {
      String path = "resource/joystick.svg";
      BgBorder borde = new BgBorder(ImageIO.read(new File(path)) ) ;
      setBorder(borde);
    } catch (IOException e) {
      System.out.println(e.getMessage());
    }
  }

  @Override
  public Posicion updateCasilla(String actionCommand) {
    if(CommandJoystick.Up.toString().equals(actionCommand))
      puntero.fila = puntero.fila-1 < 0 ? Utils.ROWS_TRES_EN_RAYA-1:puntero.fila-1;
    if(CommandJoystick.Down.toString().equals(actionCommand))
      puntero.fila = (puntero.fila+1)%Utils.ROWS_TRES_EN_RAYA;
    if(CommandJoystick.Right.toString().equals(actionCommand))
      puntero.columna = (puntero.columna+1)%Utils.COLUMNS_TRES_EN_RAYA;
    if(CommandJoystick.Left.toString().equals(actionCommand))
      puntero.columna = puntero.columna-1 < 0 ? Utils.COLUMNS_TRES_EN_RAYA-1 : puntero.columna-1;
    return TransformacionGeometrica.escalar(puntero.columna,puntero.fila,Utils.DISTACIA_CASILLA);
  }

}
