package tresenraya.migii.userinterface.components.menu;

import java.awt.Font;
import java.awt.Menu;
import java.awt.MenuItem;

class FormatMenu extends Menu {

   private Font textoFormato = new Font("Comic Sans MS", Font.BOLD, 50 );

   FormatMenu(){
    super("Format");
    initItem();
  }

   private void initItem() {
     MenuItem bold = new MenuItem("Bold");
     add(bold);
   }

 }
