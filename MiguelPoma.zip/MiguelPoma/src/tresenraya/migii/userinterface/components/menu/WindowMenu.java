package tresenraya.migii.userinterface.components.menu;

import java.awt.Menu;

 class WindowMenu extends Menu {

   WindowMenu(){
    super("Window");
  }

}
