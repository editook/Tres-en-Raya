package tresenraya.migii.userinterface.components.menu;

import tresenraya.migii.listener.componentmanager.MenuManager;
import java.awt.MenuBar;

public class MenuComponent extends MenuBar {

  private ViewMenu viewMenu;
  private MenuManager menuManager;

  public MenuComponent(){
    initComponents();
    disabledView1();
  }

  private void initComponents() {
    AppMenu appMenu = new AppMenu();
    FileMenu fileMenu = new FileMenu();
    EditMenu editMenu = new EditMenu();
    viewMenu = new ViewMenu();

    add(appMenu);
    add(fileMenu);
    add(editMenu);
    add(viewMenu);
  }

  public void disabledView1(){
    viewMenu.disableViewClasic();
  }

  public void disabledView2() {
    viewMenu.disableViewModerno();
  }

  public void disabledView3() {
    viewMenu.disableViewJugadorJugador();
  }

}
