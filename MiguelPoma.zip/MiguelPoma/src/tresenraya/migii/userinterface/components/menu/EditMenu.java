package tresenraya.migii.userinterface.components.menu;

import tresenraya.migii.userinterface.events.Event;
import tresenraya.migii.userinterface.events.EventManager;
import java.awt.Menu;
import java.awt.MenuItem;

class EditMenu extends Menu {

  private EventManager eventManager;

  EditMenu(){
    super("Edit");
    eventManager = EventManager.getInstance();
    initItem();
  }

   private void initItem() {
     MenuItem nuevoJugador = new MenuItem("NuevoJugador");
     nuevoJugador.addActionListener(eventManager.getListener(Event.MostrarFormDialogPlayer));
     add(nuevoJugador);
   }

 }
