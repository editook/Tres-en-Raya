package tresenraya.migii.userinterface.components.menu;

import tresenraya.migii.userinterface.events.Event;
import tresenraya.migii.userinterface.events.EventManager;
import java.awt.Menu;
import java.awt.MenuItem;

class AppMenu extends Menu {

  private EventManager eventManager;

  AppMenu(){
    super("App");
    eventManager = EventManager.getInstance();
    initItem();
  }

  private void initItem() {

    MenuItem menuAbout = new MenuItem("About...");
    MenuItem menuExit = new MenuItem("Quit Tres En Raya");

    menuAbout.addActionListener(eventManager.getListener(Event.About));
    menuExit.addActionListener(eventManager.getListener(Event.Exit));

    add(menuAbout);
    addSeparator();
    add(menuExit);
  }

}
