package tresenraya.migii.userinterface.components.menu;

import java.awt.Menu;

class HelpMenu extends Menu {

   HelpMenu(){
    super("Help");
     initItem();
   }

   private void initItem() {
   }

 }
