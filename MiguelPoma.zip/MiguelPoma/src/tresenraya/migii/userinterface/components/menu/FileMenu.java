package tresenraya.migii.userinterface.components.menu;

import tresenraya.migii.userinterface.events.Event;
import tresenraya.migii.userinterface.events.EventManager;
import java.awt.Menu;
import java.awt.MenuItem;

class FileMenu extends Menu {

  private EventManager eventManager;

   FileMenu(){
    super("File");
    eventManager = EventManager.getInstance();
    initItem();
  }

  private void initItem() {

    MenuItem menuNewGame = new MenuItem("New Game");

    menuNewGame.addActionListener(eventManager.getListener(Event.NewGame));

    add(menuNewGame);

  }

}
