package tresenraya.migii.userinterface.components.menu;

import tresenraya.migii.userinterface.events.Event;
import tresenraya.migii.userinterface.components.boardgame.Tablero;
import tresenraya.migii.userinterface.events.EventManager;
import java.awt.Menu;
import java.awt.MenuItem;

class ViewMenu extends Menu {

  private EventManager eventManager;
  private MenuItem tableroBotones;
  private MenuItem tableroDibujo;
  private MenuItem juegoJugadorJugador;

  ViewMenu(){
    super("View");
    eventManager = EventManager.getInstance();
    initItem();
  }

   private void initItem() {
     Menu juegoMaquinaJugador = new Menu("ModelJugador vs Maquina");
     juegoJugadorJugador = new MenuItem("ModelJugador vs ModelJugador");

     tableroBotones = new MenuItem("Tablero Clasico");
     tableroDibujo = new MenuItem("Tablero Arcade");
     MenuItem tablaPosiciones = new MenuItem("TablaPosiciones");

     tableroBotones.setActionCommand(Tablero.Default.toString());
     tableroDibujo.setActionCommand(Tablero.Arcade.toString());
     juegoJugadorJugador.setActionCommand(Tablero.Moderno.toString());

     tableroBotones.addActionListener(eventManager.getListener(Event.Url));
     tableroDibujo.addActionListener(eventManager.getListener(Event.Url));
     juegoJugadorJugador.addActionListener(eventManager.getListener(Event.Url));
     tablaPosiciones.addActionListener(eventManager.getListener(Event.TablaPosiciones));

     juegoMaquinaJugador.add(tableroBotones);
     juegoMaquinaJugador.add(tableroDibujo);

     add(juegoMaquinaJugador);
     add(juegoJugadorJugador);
     addSeparator();
     add(tablaPosiciones);
   }

   void disableViewClasic() {
     tableroBotones.setEnabled(false);
     tableroDibujo.setEnabled(true);
     juegoJugadorJugador.setEnabled(true);
  }

  void disableViewModerno() {
    tableroBotones.setEnabled(true);
    tableroDibujo.setEnabled(false);
    juegoJugadorJugador.setEnabled(true);
  }

  void disableViewJugadorJugador() {
    tableroBotones.setEnabled(true);
    tableroDibujo.setEnabled(true);
    juegoJugadorJugador.setEnabled(false);
  }

}
