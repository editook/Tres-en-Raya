package tresenraya.migii.userinterface.components.frame;

import tresenraya.migii.library.Utils;
import java.awt.BorderLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class MainFrame extends FrameComponent {

  public MainFrame(){
    setTitle(Utils.NOMBRE_JUEGO);
    initBaseDisplay();
  }

  private void initBaseDisplay() {
    getContentPane().setLayout(new BorderLayout());
    setResizable( true );
    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent evt) {
        exit();
      }
    });
  }

  @Override
  public void exit() {
    System.exit(0);
  }

}
