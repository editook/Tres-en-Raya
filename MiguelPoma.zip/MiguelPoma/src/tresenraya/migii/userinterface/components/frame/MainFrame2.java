package tresenraya.migii.userinterface.components.frame;

import tresenraya.migii.userinterface.components.joystick.JoystickComponent;
import tresenraya.migii.userinterface.components.tableplayer.TablePlayerComponent;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Toolkit;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;

/**
 * @author: Miguel Poma (Migi)
 * @version: 1.0.0.0
 * @release date: 30/09/2018
 * */

public class MainFrame2 extends FrameComponent {

  private final int WIDTH = 600;
  private final int HEIGHT = 400;

  public MainFrame2(){
    setTitle("Maquina vs ModelJugador");
    createDisplay();
  }

  private void createDisplay(){
    setSize(WIDTH,HEIGHT);
    setPositionScreen();
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setResizable(false);
    getContentPane().setLayout(new BorderLayout());
  }

  private void setPositionScreen() {
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    setLocation(screenSize.width/2 - WIDTH/2, screenSize.height/2 - HEIGHT/2);
  }

  public void setComponents(TablePlayerComponent tablePlayerComponent, JPanel tableroComponent, JoystickComponent joystickComponent) {
    JTabbedPane informationPanel = new JTabbedPane();
    informationPanel.addTab("JoystickComponent ", joystickComponent);
    JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, informationPanel,
        tableroComponent);
    splitPane.setOneTouchExpandable(true);
    getContentPane().add(splitPane,BorderLayout.WEST);
    getContentPane().add(tableroComponent,BorderLayout.CENTER);
  }

  public void exit() {
    System.exit( 0 );
  }

}
 