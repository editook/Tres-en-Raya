package tresenraya.migii.userinterface.components.frame;

import javax.swing.JFrame;

public abstract class FrameComponent extends JFrame {

  public abstract void exit();

}
