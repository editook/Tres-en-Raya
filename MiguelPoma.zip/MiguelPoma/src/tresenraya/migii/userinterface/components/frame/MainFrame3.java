package tresenraya.migii.userinterface.components.frame;

import tresenraya.migii.userinterface.components.boardgame.TableroComponent;
import tresenraya.migii.userinterface.components.joystick.JoystickComponent;
import tresenraya.migii.userinterface.events.Event;
import tresenraya.migii.userinterface.components.joystick.Joystick2;
import tresenraya.migii.logicadenegocio.tablero.implemetations.TipoFicha;
import tresenraya.migii.userinterface.components.formplayer.FormComponent;
import tresenraya.migii.userinterface.components.tableplayer.TablePlayerComponent;
import tresenraya.migii.userinterface.events.EventManager;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Toolkit;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;

/**
 * @author: Miguel Poma (Migi)
 * @version: 1.0.0.0
 * @release date: 30/09/2018
 * */

public class MainFrame3 extends FrameComponent {

  private final int WIDTH = 600;
  private final int HEIGHT = 400;

  private EventManager listenerManager = EventManager.getInstance();
  private FormComponent formComponent;
  private JTextField nameField1;
  private JComboBox<TipoFicha> fichas;

  public MainFrame3(){
    setTitle("ModelJugador vs ModelJugador");
    createDisplay();
  }

  private void createDisplay(){
    setSize(WIDTH,HEIGHT);
    setPositionScreen();
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setResizable(false);
  }

  private void setPositionScreen() {
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    setLocation(screenSize.width/2 - WIDTH/2, screenSize.height/2 - HEIGHT/2);
  }

  public void setComponents(JPanel boardGUI, TablePlayerComponent tablePlayerComponent, JoystickComponent joystick2) {
    getContentPane().setLayout(new BorderLayout());
    JTabbedPane gamePanel = new JTabbedPane();
    //boardGUI.setBorderPanel("X(ModelJugador-Default) vs O(ModelJugador-Default)");
    gamePanel.addTab("Tablero",joystick2);
    gamePanel.addTab("Posiciones", tablePlayerComponent);
    JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, gamePanel, boardGUI);
    splitPane.setOneTouchExpandable(true);
    getContentPane().add(splitPane,BorderLayout.WEST);
    getContentPane().add(boardGUI,BorderLayout.CENTER);
  }

  /*
  private void createFormPlayer() {
    JLabel tag;

    nameField1 = new JTextField(10);

    JButton search = new JButton("Archivo");
    JButton okButton = new JButton("OK");
    JButton cancelButton = new JButton("Cancel");
     fichas = new JComboBox<>();
    fichas.addItem(TipoFicha.Cruz);
    fichas.addItem(TipoFicha.Circulo);

    search.addActionListener(listenerManager.getListener(Event.SearchAlgorithm));
    okButton.addActionListener(listenerManager.getListener(Event.NuevoJugador));
    cancelButton.addActionListener(listenerManager.getListener(Event.OcultarFormDialogPlayer));

    tag = new JLabel("Nombre ModelJugador");
    formComponent.addRow(tag,nameField1);
    tag = new JLabel("Artificial Intelligent");
    formComponent.addRow(tag,search);
    tag = new JLabel("Ficha");
    formComponent.addRow(tag,fichas);
    formComponent.addRow(okButton,cancelButton);
  }*/

  public void exit() {
    System.exit( 0 );
  }

}
 