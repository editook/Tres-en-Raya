package tresenraya.migii.userinterface.components;

import tresenraya.migii.library.Utils;
import java.awt.Component;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class NotificadorComponent extends Component {

  private JFrame frame;

  public NotificadorComponent(JFrame frame){
    this.frame = frame;
  }

  public void mostrarAviso(String mensaje1, String mensaje2) {
    JOptionPane.showMessageDialog( frame, mensaje1, mensaje2, JOptionPane.INFORMATION_MESSAGE );
  }

  public void errorCasillaOcupada() {
    String msj1 = "This square is already occupied, \nplease try another one.";
    String msj2 = "Oops...";
    JOptionPane.showMessageDialog( frame, msj1, msj2, JOptionPane.ERROR_MESSAGE );
  }

  public int getDesicionGanador(String winner) {
    String output = "The player \"" + winner + "\" has won!!! \nWould you like to play again?";
    return JOptionPane.showConfirmDialog( frame, output, "Congratulations",
        JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE );
  }

  public void empate() {
    String msj1 = "It's a tie, baby!!! \nLets play again!";
    String msj2 = "That was a game...";
    JOptionPane.showMessageDialog( frame, msj1, msj2, JOptionPane.INFORMATION_MESSAGE );
  }

  public void about(){
    String msj = "This simple game is created by \nD3M0L1SH3R.";
    JOptionPane.showMessageDialog( frame, msj, Utils.NOMBRE_JUEGO, JOptionPane.INFORMATION_MESSAGE );
  }

}
