package tresenraya.migii.userinterface.components.tableplayer;

import tresenraya.migii.listener.componentmanager.TablePlayerManager;
import tresenraya.migii.listener.interfaces.IEventRefresh;
import tresenraya.migii.persistencia.ModelJugador;
import tresenraya.migii.userinterface.events.EventManager;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.util.List;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

/**
 * @author migi
 */
public class TablePlayerComponent extends JPanel implements IEventRefresh {

  private JTable table;
  private PlayerModel modeloJugador;
  private TablePlayerManager listenerTablePosition;
  private EventManager listenerManager;

  public TablePlayerComponent(){
    listenerManager = EventManager.getInstance();
    initComponent();
  }

  private void initComponent() {
    modeloJugador = new PlayerModel();
    table = new JTable(modeloJugador);
    setLayout(new BorderLayout());
    add(new JScrollPane(table), BorderLayout.CENTER);
  }

  @Override
  public Dimension getPreferredSize(){
    return new Dimension(200, Short.MAX_VALUE);
  }

  public void setData(List<ModelJugador> db) {
    modeloJugador.setData(db);
  }

  @Override
  public void update() {
    modeloJugador.fireTableDataChanged();
  }

}
