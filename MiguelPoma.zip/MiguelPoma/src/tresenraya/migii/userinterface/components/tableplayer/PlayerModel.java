package tresenraya.migii.userinterface.components.tableplayer;

import tresenraya.migii.persistencia.ModelJugador;
import java.util.List;
import javax.swing.table.AbstractTableModel;

public  class PlayerModel extends AbstractTableModel {

  private List<ModelJugador> jugadores;

  private String[] nombreColumnas = {"tresenraya.Posicion", "Nombre", "Triunfos"};

  @Override
  public String getColumnName(int column) {
    return nombreColumnas[column];
  }

  @Override
  public int getRowCount() {
    int limite = 10;
    if(jugadores.size() < limite){
      limite = jugadores.size();
    }
    return limite;
  }

  @Override
  public int getColumnCount() {
    return nombreColumnas.length;
  }

  public void setData(List<ModelJugador> jugadores) {
    this.jugadores = jugadores;
  }

  @Override
  public Object getValueAt(int fila, int columna) {
    ModelJugador modelJugador = jugadores.get(fila);
    switch(columna) {
      case 0:
        return fila;
      case 1:
        return modelJugador.getNombre();
      case 2:
        return modelJugador.getJuegosGanados();
    }
    return null;
  }

}
