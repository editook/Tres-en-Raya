package tresenraya.migii.userinterface.components.formplayer;

import tresenraya.migii.logicadenegocio.tablero.implemetations.TipoFicha;

public class EventForm {
  private String nombre;
  private Class myClass;
  private TipoFicha ficha;

  public String getNombre() {
    return nombre;
  }

  public Class getMyClass() {
    return myClass;
  }

  public TipoFicha getFicha() {
    return ficha;
  }

  public void setNombre(String nombre) {
    this.nombre = nombre;
  }

  public void setMyClass(Class myClass) {
    this.myClass = myClass;
  }

  public void setFicha(TipoFicha ficha) {
    this.ficha = ficha;
  }

}
