package tresenraya.migii.userinterface.components.formplayer;

import java.io.File;
import javax.swing.filechooser.FileFilter;
import tresenraya.migii.library.Utils;

class AlgoritmoFileFilter extends FileFilter {

  @Override
  public boolean accept(File file) {

    if(file.isDirectory()) {
      return true;
    }

    String name = file.getName();

    String extension = Utils.getFileExtension(name);

    if(extension == null) {
      return false;
    }

    if(extension.equals("class")) {
      return true;
    }

    return false;
  }

  @Override
  public String getDescription() {
    return "Algoritmo Inteligente file (*.class)";
  }

}
