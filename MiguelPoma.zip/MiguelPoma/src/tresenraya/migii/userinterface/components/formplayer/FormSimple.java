package tresenraya.migii.userinterface.components.formplayer;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JTextField;
import tresenraya.migii.logicadenegocio.tablero.implemetations.TipoFicha;
import tresenraya.migii.persistencia.ModelJugador;
import tresenraya.migii.userinterface.BgBorder;
import tresenraya.migii.userinterface.events.Event;
import tresenraya.migii.userinterface.events.EventManager;

public class FormSimple extends FormComponent {

  private GridBagConstraints gc;
  private JTextField nameField;
  private EventManager listenerManager;
  private JButton okButton;
  private JButton cancelButton;
  private JLabel namePlayer;

  public FormSimple(){
    listenerManager = EventManager.getInstance();
    setLayout(new GridBagLayout());
    gc = new GridBagConstraints();
    gc.gridy = 0;
    setSize(400, 300);
    initForm();
  }

  private void createBaseForm() {
    okButton = new JButton("OK");
    cancelButton = new JButton("Cancel");
    okButton.addActionListener(listenerManager.getListener(Event.NuevoJugador));
    cancelButton.addActionListener(listenerManager.getListener(Event.OcultarFormDialogPlayer));
    addRow(okButton,cancelButton);
    try {
      String path = "resource/gamer.png";
      BgBorder borde = new BgBorder(ImageIO.read(new File(path)) ) ;
      setBorder(borde);
    } catch (IOException e) {
      System.err.println(e.getMessage());
    }
  }

  public void addRow(JComponent column1, JComponent column2){
    gc.weightx = 1;
    gc.weighty = 1;
    gc.fill = GridBagConstraints.NONE;
    gc.gridx = 0;
    add(column1, gc);
    gc.gridx++;
    add(column2, gc);
    gc.gridy++;
  }

  public EventForm getPlayerData() {
    EventForm eventForm = new EventForm();
    eventForm.setNombre(nameField.getText());
    eventForm.setFicha(TipoFicha.Cruz);
    return eventForm;
  }

  @Override
  public void openFileChooser() {

  }

  public void cleanFields() {
    nameField.setText("");
  }

  public void initForm() {
    gc.gridy = 0;
    nameField = new JTextField(10);
    namePlayer = new JLabel("Nombre ModelJugador");
    namePlayer.setForeground(Color.blue);
    namePlayer.setFont(new Font("Serif", Font.BOLD, 15));
    addRow(namePlayer,nameField);
    createBaseForm();
  }

  private void cleanForm() {
    nameField.setText("");
  }

}
