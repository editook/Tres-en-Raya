package tresenraya.migii.userinterface.components.formplayer;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JTextField;
import tresenraya.migii.logicadenegocio.tablero.implemetations.TipoFicha;
import tresenraya.migii.userinterface.BgBorder;
import tresenraya.migii.userinterface.events.Event;
import tresenraya.migii.userinterface.events.EventManager;

public class FormModerno extends FormComponent{
  private GridBagConstraints gc;
  private JTextField nameField;
  private EventManager listenerManager;
  private JFileChooser fileChooser;
  private Class algorithm;
  private JComboBox<TipoFicha> combo;

  public FormModerno(){
    this.algorithm = null;
    fileChooser = new JFileChooser();
    fileChooser.addChoosableFileFilter(new AlgoritmoFileFilter());
    listenerManager = EventManager.getInstance();
    setLayout(new GridBagLayout());
    gc = new GridBagConstraints();
    gc.gridy = 0;
    setSize(400, 300);
    initForm();
  }

  private void initForm() {
    gc.gridy = 0;
    JButton search = new JButton("Archivo");
    nameField = new JTextField(10);
    search.addActionListener(listenerManager.getListener(Event.SearchAlgorithm));
    JLabel namePlayer = new JLabel("Nombre ModelJugador");
    addRow(namePlayer,nameField);
    JLabel nameStrategy = new JLabel("Artificial Intelligent");
    nameStrategy.setForeground(Color.blue);
    nameStrategy.setFont(new Font("Serif", Font.BOLD, 15));
    combo = new JComboBox<>();
    combo.addItem(TipoFicha.Cruz);
    combo.addItem(TipoFicha.Circulo);
    addRow(nameStrategy, search);
    addRow(new JLabel("Ficha"), combo);
    createBaseForm();
  }

  private void createBaseForm() {
    JButton okButton = new JButton("OK");
    JButton cancelButton = new JButton("Cancel");
    okButton.addActionListener(listenerManager.getListener(Event.NuevoJugador));
    cancelButton.addActionListener(listenerManager.getListener(Event.OcultarFormDialogPlayer));
    addRow(okButton, cancelButton);
    try {
      String path = "resource/gamer.png";
      BgBorder borde = new BgBorder(ImageIO.read(new File(path)) ) ;
      setBorder(borde);
    } catch (IOException e) {
      System.err.println(e.getMessage());
    }
  }

   private void addRow(JComponent column1, JComponent column2){
    gc.weightx = 1;
    gc.weighty = 1;
    gc.fill = GridBagConstraints.NONE;
    gc.gridx = 0;
    add(column1, gc);
    gc.gridx++;
    add(column2, gc);
    gc.gridy++;
  }

  public EventForm getPlayerData() {
    EventForm eventForm = new EventForm();
    eventForm.setNombre(nameField.getText());
    eventForm.setFicha((TipoFicha) combo.getSelectedItem());
    eventForm.setMyClass(algorithm);
    return eventForm;
  }

  public void cleanFields() {
    nameField.setText("");
  }

  public void openFileChooser() {
    String nameFile,myPackege;
    if(fileChooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION){
      File file = fileChooser.getSelectedFile().getParentFile();
      nameFile = fileChooser.getSelectedFile().getName();
      try {
        System.out.println(file.toURI().toURL().toString());
        URLClassLoader loader = new URLClassLoader(new URL[]{ new URL(file.toURI().toURL().toString()) });
        myPackege = "estrategia."+nameFile.substring(0,nameFile.lastIndexOf("."));
        algorithm = loader.loadClass(myPackege );
      } catch (MalformedURLException ignored) {
      } catch (ClassNotFoundException e) {
        e.printStackTrace();
      }
    }
  }


}
