package tresenraya.migii.userinterface.components.formplayer;

import javax.swing.JPanel;

public abstract class FormComponent extends JPanel {


  public abstract EventForm getPlayerData();

  public abstract void openFileChooser();

  public abstract void cleanFields();

}
