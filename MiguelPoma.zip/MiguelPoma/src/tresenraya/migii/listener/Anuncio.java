package tresenraya.migii.listener;

import tresenraya.migii.persistencia.ModelJugador;
import tresenraya.migii.listener.interfaces.IEventRefresh;
import tresenraya.migii.listener.interfaces.ICambiable;
import tresenraya.migii.listener.interfaces.IEventGame;
import tresenraya.migii.listener.interfaces.IAviso;
import tresenraya.migii.listener.interfaces.IEventNotificador;
import tresenraya.migii.listener.interfaces.IEventForm;
import tresenraya.migii.listener.interfaces.IEventJoystick;
import tresenraya.migii.listener.interfaces.IEventTablePlayer;
import tresenraya.migii.listener.interfaces.IEventBoardGame;
import tresenraya.Posicion;
import java.util.Vector;
import tresenraya.migii.userinterface.components.formplayer.EventForm;

public abstract class Anuncio {

  private Vector<IAviso> components = new Vector<>();

  public void comunicar(IAviso component){
    this.components.add(component);
  }

  public void removeAllObserver(){
    this.components.removeAllElements();
  }

  protected void notifyGanador(ModelJugador theWinner){
    IEventNotificador eventNotificador;
    for (IAviso obs: components){
      if(obs instanceof IEventNotificador){
        eventNotificador = (IEventNotificador) obs;
        eventNotificador.mostrarGanador(theWinner.getNombre());
      }
    }
  }

  protected void notifyCasillaOcupada(){
    IEventNotificador IEventNotificador;
    for (IAviso obs: components){
      if(obs instanceof IEventNotificador){
        IEventNotificador = (IEventNotificador) obs;
        IEventNotificador.errorCasillaOcupada();
      }
    }
  }

  protected void notifyJugada(Posicion posicion, String cadena){
    IEventBoardGame tablero;
    for (IAviso obs : components){
      if (obs instanceof IEventBoardGame){
        tablero = (IEventBoardGame) obs;
        tablero.drawCasilla(posicion, cadena);
      }
    }
  }

  protected void notifyAbout(){
    IEventNotificador eventNotificador;
    for (IAviso obs : components){
      if (obs instanceof IEventNotificador){
        eventNotificador = (IEventNotificador) obs;
        eventNotificador.mostrarAbout();
      }
    }
  }

  protected void notifyNewPlayer(){
    IEventForm eventForm;
    for (IAviso obs : components){
      if(obs instanceof IEventForm){
        eventForm = (IEventForm) obs;
        eventForm.registrarJugador();
      }
    }
  }

  protected void notifyNewCheck(Posicion posicion){
    IEventJoystick eventJoystick;
    for (IAviso obs : components){
      if (obs instanceof IEventJoystick){
        eventJoystick = (IEventJoystick) obs;
        eventJoystick.jugar(posicion);
      }
    }
  }

  protected void notifyExitGame(){
    IEventGame IEventGame;
    for (IAviso obs : components){
      if (obs instanceof IEventGame){
        IEventGame = (IEventGame) obs;
        IEventGame.salirJuego();
      }
    }
  }

  protected void notifyNewFormPlayer(){
    IEventForm IEventForm;
    for (IAviso obs : components){
      if (obs instanceof IEventForm){
        IEventForm = (IEventForm) obs;
        IEventForm.mostrarForm();
      }
    }
  }

  protected void notifyCancelFormPlayer(){
    IEventForm IEventForm;
    for (IAviso obs : components){
      if (obs instanceof IEventForm){
        IEventForm = (IEventForm) obs;
        IEventForm.cancelForm();
      }
    }
  }

  protected void notifyEventJoystick(String direccion){
    IEventJoystick IEventJoystick;
    for (IAviso obs : components){
      if (obs instanceof IEventJoystick){
        IEventJoystick = (IEventJoystick) obs;
        IEventJoystick.changeJoystick(direccion);
      }
    }
  }

  protected void notifySearchAlgorithm(){
    IEventForm IEventForm;
    for (IAviso obs : components){
      if (obs instanceof IEventForm){
        IEventForm = (IEventForm) obs;
        IEventForm.searchEstrategia();
      }
    }
  }

  protected void notifyTablePlayer(){
    IEventTablePlayer IEventTablePlayer;
    for (IAviso obs : components){
      if (obs instanceof IEventTablePlayer){
        IEventTablePlayer = (IEventTablePlayer) obs;
        IEventTablePlayer.showTablePlayer();
      }
    }
  }

  protected void notifyChangeView(String view){
    ICambiable ICambiable;
    for (IAviso obs : components){
      if (obs instanceof ICambiable){
        ICambiable = (ICambiable) obs;
        ICambiable.changeView(view);
      }
    }
  }

  protected void notifyNewGame(){
    IEventGame IEventGame;
    for (IAviso obs : components)
      if (obs instanceof IEventGame) {
        IEventGame = (IEventGame) obs;
        IEventGame.setNewGame();
      }
  }

  protected void notifyUpdateTablero(String tablero){
    IEventBoardGame IEventBoardGame;
    for (IAviso obs : components){
      if (obs instanceof IEventBoardGame){
        IEventBoardGame = (IEventBoardGame) obs;
        IEventBoardGame.setNewTablero(tablero);
      }
    }
  }

  protected void notifyUpdate(){
    IEventRefresh eventRefresh;
    for (IAviso obs : components){
      if (obs instanceof IEventRefresh){
        eventRefresh = (IEventRefresh) obs;
        eventRefresh.update();
      }
    }
  }

  protected void notifyRestartGame() {
    IEventGame eventGame;
    for (IAviso obs : components){
      if (obs instanceof IEventGame){
        eventGame = (IEventGame) obs;
        eventGame.restartGame();
      }
    }
  }

  protected void notifyEmpate() {
    IEventNotificador notificador;
    for (IAviso obs: components){
      if(obs instanceof IEventNotificador){
        notificador = (IEventNotificador) obs;
        notificador.empate();
      }
    }
  }

  protected void notifyJugadorX(EventForm eventForm) {
    IEventJoystick eventJoystick;
    for (IAviso obs : components){
      if (obs instanceof IEventJoystick){
        eventJoystick = (IEventJoystick) obs;
        eventJoystick.cargarJugadorX(eventForm);
      }
    }
  }

  protected void notifyJugadorO(EventForm eventForm) {
    IEventJoystick eventJoystick;
    for (IAviso obs : components){
      if (obs instanceof IEventJoystick){
        eventJoystick = (IEventJoystick) obs;
        eventJoystick.cargarJugadorO(eventForm);
      }
    }
  }

  protected void notifyMovimientoPuntero(Posicion posicion, String cadena){
    IEventBoardGame tablero;
    for (IAviso obs : components){
      if (obs instanceof IEventBoardGame){
        tablero = (IEventBoardGame) obs;
        tablero.drawPuntero(posicion, cadena);
      }
    }
  }

}
