package tresenraya.migii.listener.interfaces;

public interface IEventForm extends IAviso {
  void registrarJugador();
  void searchEstrategia();
  void mostrarForm();
  void cancelForm();
}
