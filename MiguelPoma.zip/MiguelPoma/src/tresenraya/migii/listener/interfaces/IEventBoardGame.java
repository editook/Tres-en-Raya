package tresenraya.migii.listener.interfaces;

import tresenraya.Posicion;

public interface IEventBoardGame extends IAviso {
  void drawCasilla(Posicion posicion, String ficha);
  void setNewGame();
  void setNewTablero(String tablero);
  void drawPuntero(Posicion posicion, String cadena);
}
