package tresenraya.migii.listener.interfaces;

public interface IEventNotificador extends IAviso {
  void mostrarAviso(String mensaje1, String mensaje2);
  void mostrarAbout();
  void errorCasillaOcupada();
  void mostrarGanador(String nombre);
  void empate();
}
