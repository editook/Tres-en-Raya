package tresenraya.migii.listener.interfaces;

public interface IAviso {

}
