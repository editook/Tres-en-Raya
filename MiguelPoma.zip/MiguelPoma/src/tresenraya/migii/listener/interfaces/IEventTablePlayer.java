package tresenraya.migii.listener.interfaces;

public interface IEventTablePlayer extends IAviso {
  void showTablePlayer();
}
