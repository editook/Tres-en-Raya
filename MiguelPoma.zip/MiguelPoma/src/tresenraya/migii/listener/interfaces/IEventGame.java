package tresenraya.migii.listener.interfaces;

public interface IEventGame extends IAviso {

  void setNewGame();
  void salirJuego();
  void restartGame();

}
