package tresenraya.migii.listener.interfaces;

import tresenraya.Posicion;
import tresenraya.migii.userinterface.components.formplayer.EventForm;

public interface IEventJoystick extends IAviso {
  void changeJoystick(String command);
  void jugar(Posicion posicion);
  void cargarJugadorX(EventForm eventForm);
  void cargarJugadorO(EventForm eventForm);
}
