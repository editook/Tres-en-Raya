package tresenraya.migii.listener.interfaces;

public interface ICambiable extends IAviso {
  void changeView(String view);
}
