package tresenraya.migii.listener.interfaces;

public interface IEventRefresh extends IAviso {
  void update();
}
