package tresenraya.migii.listener.componentmanager;

import tresenraya.migii.listener.interfaces.IEventRefresh;
import tresenraya.migii.listener.interfaces.IEventTablePlayer;
import tresenraya.migii.persistencia.DataBase;
import tresenraya.migii.userinterface.components.tableplayer.TablePlayerComponent;
import tresenraya.migii.userinterface.events.Event;
import tresenraya.migii.userinterface.events.EventManager;
import tresenraya.migii.userinterface.events.TablePlayerEvent;
import javax.swing.JDialog;

public class TablePlayerManager implements IEventTablePlayer, IEventRefresh {

  private TablePlayerComponent tablePlayerComponent;
  private JDialog dialog = new JDialog();
  private DataBase dataBase = DataBase.getInstance();

  TablePlayerManager() {
    createListener();
    this.tablePlayerComponent = new TablePlayerComponent();
    this.tablePlayerComponent.setData(dataBase.getJugadores());
    dialog.setSize(200,300);
  }

  private void createListener() {
    EventManager eventManager = EventManager.getInstance();
    TablePlayerEvent tablePlayerEvent = new TablePlayerEvent();
    tablePlayerEvent.comunicar(this);
    eventManager.addListener(Event.TablaPosiciones, tablePlayerEvent);
  }

  @Override
  public void showTablePlayer() {
    dialog.add(tablePlayerComponent);
    dialog.setVisible(true);
  }

  @Override
  public void update() {
    this.tablePlayerComponent.update();
  }

  TablePlayerComponent getTablePlayer() {
    return tablePlayerComponent;
  }

}
