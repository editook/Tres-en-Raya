package tresenraya.migii.listener.componentmanager;

import tresenraya.migii.listener.Anuncio;
import tresenraya.migii.listener.interfaces.ICambiable;
import tresenraya.migii.userinterface.components.boardgame.Tablero;
import tresenraya.migii.userinterface.components.menu.MenuComponent;
import tresenraya.migii.userinterface.events.Event;
import tresenraya.migii.userinterface.events.EventManager;
import tresenraya.migii.userinterface.events.UrlEvent;
import java.awt.MenuBar;

public class MenuManager extends Anuncio implements ICambiable {

  private MenuComponent menuComponent;

  public MenuManager(){
    setListener();
    this.menuComponent = new MenuComponent();
  }

  private void setListener() {
    EventManager eventManager = EventManager.getInstance();
    UrlEvent urlEvent = (UrlEvent) eventManager.getListener(Event.Url);
    urlEvent.comunicar(this);
  }

  @Override
  public void changeView(String view) {
    if (Tablero.Default.toString().equals(view))
      this.menuComponent.disabledView1();
    if (Tablero.Arcade.toString().equals(view))
      this.menuComponent.disabledView2();
    if (Tablero.Moderno.toString().equals(view))
      this.menuComponent.disabledView3();
  }

  MenuBar getMenuBar(){
    return menuComponent;
  }

}
