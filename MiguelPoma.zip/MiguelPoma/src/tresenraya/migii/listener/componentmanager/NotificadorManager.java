package tresenraya.migii.listener.componentmanager;

import tresenraya.migii.listener.Anuncio;
import tresenraya.migii.listener.interfaces.IEventNotificador;
import tresenraya.migii.userinterface.MyGame;
import tresenraya.migii.userinterface.components.NotificadorComponent;
import tresenraya.migii.userinterface.events.AboutEvent;
import tresenraya.migii.userinterface.events.Event;
import tresenraya.migii.userinterface.events.EventManager;

public class NotificadorManager extends Anuncio implements IEventNotificador {

  private NotificadorComponent notificadorComponent;

  NotificadorManager(MyGame frame) {
    createListener();
    this.notificadorComponent = new NotificadorComponent(frame);
  }

  private void createListener() {
    EventManager eventManager = EventManager.getInstance();
    AboutEvent aboutEvent = new AboutEvent();
    aboutEvent.comunicar(this);
    eventManager.addListener(Event.About, aboutEvent);
  }

  @Override
  public void mostrarAviso(String mensaje1, String mensaje2) {
    this.notificadorComponent.mostrarAviso(mensaje1,mensaje2);
  }

  @Override
  public void mostrarAbout() {
    this.notificadorComponent.about();
  }

  @Override
  public void errorCasillaOcupada() {
    this.notificadorComponent.errorCasillaOcupada();
  }

  @Override
  public void mostrarGanador(String nombre) {
    int desicion = this.notificadorComponent.getDesicionGanador(nombre);
    if (desicion == 0){
      notifyRestartGame();
    }else{
      System.exit(0);
    }
  }

  @Override
  public void empate() {
    this.notificadorComponent.empate();
    notifyRestartGame();
  }

}
