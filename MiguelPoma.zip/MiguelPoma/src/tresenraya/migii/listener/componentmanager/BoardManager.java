package tresenraya.migii.listener.componentmanager;

import tresenraya.migii.listener.interfaces.ICambiable;
import tresenraya.migii.listener.interfaces.IEventBoardGame;
import tresenraya.migii.logicadenegocio.juego.implemetations.TresEnRaya;
import tresenraya.Posicion;
import tresenraya.migii.userinterface.components.boardgame.BoardPaint;
import tresenraya.migii.userinterface.components.boardgame.Tablero;
import tresenraya.migii.userinterface.components.boardgame.BoardButton;
import tresenraya.migii.userinterface.components.boardgame.TableroComponent;
import tresenraya.migii.userinterface.events.Event;
import tresenraya.migii.userinterface.events.EventManager;
import tresenraya.migii.userinterface.events.UrlEvent;

public class BoardManager implements IEventBoardGame, ICambiable {

  private TableroComponent tableroComponent;
  private BoardPaint boardGUI;
  private BoardButton boardButton;
  private TresEnRaya tresEnRaya;

  BoardManager(TresEnRaya tresEnRaya) {
    this.tresEnRaya = tresEnRaya;
    boardButton = new BoardButton();
    this.tableroComponent = boardButton;
    setListeners();
    initBoards();
  }

  private void setListeners() {
    EventManager eventManager = EventManager.getInstance();
    UrlEvent urlEvent = (UrlEvent) eventManager.getListener(Event.Url);
    urlEvent.comunicar(this);
  }

  private void initBoards(){
    boardGUI = new BoardPaint(":)" );
    boardGUI.setBorderPanel("X (Anonimo-Default) vs O (Maquina-Random)");
  }

  @Override
  public void drawCasilla(Posicion posicion, String ficha) {
    this.tableroComponent.drawCasilla(posicion,ficha);
  }

  @Override
  public void setNewGame() {
    this.tableroComponent.setNewGame();
  }

  @Override
  public void setNewTablero(String tablero) {
    this.tableroComponent.setNewTablero(tablero);
  }

  @Override
  public void drawPuntero(Posicion posicion, String cadena) {
    this.tableroComponent.drawPuntero(posicion,cadena);
  }

  TableroComponent getComponent() {
    this.tableroComponent.setNewTablero(this.tresEnRaya.toString());
    return tableroComponent;
  }

  @Override
  public void changeView(String view) {
    if(Tablero.Default.toString().equals(view))
      this.tableroComponent = this.boardButton;
    if (Tablero.Arcade.toString().equals(view)){
      this.boardGUI.mostrarPuntero(true);
      this.tableroComponent = this.boardGUI;
    }
    if (Tablero.Moderno.toString().equals(view)){
      this.boardGUI.mostrarPuntero(false);
      this.tableroComponent = this.boardGUI;
    }
  }

}
