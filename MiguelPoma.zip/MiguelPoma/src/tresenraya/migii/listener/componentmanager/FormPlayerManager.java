package tresenraya.migii.listener.componentmanager;

import tresenraya.migii.listener.Anuncio;
import tresenraya.migii.listener.interfaces.ICambiable;
import tresenraya.migii.listener.interfaces.IEventForm;
import tresenraya.migii.persistencia.DataBase;
import tresenraya.migii.logicadenegocio.tablero.implemetations.TipoFicha;
import tresenraya.migii.userinterface.components.formplayer.EventForm;
import tresenraya.migii.userinterface.components.formplayer.FormArcade;
import tresenraya.migii.userinterface.components.formplayer.FormComponent;
import tresenraya.migii.userinterface.components.boardgame.Tablero;
import tresenraya.migii.userinterface.components.formplayer.FormModerno;
import tresenraya.migii.userinterface.components.formplayer.FormSimple;
import tresenraya.migii.userinterface.events.CancelFormEvent;
import tresenraya.migii.userinterface.events.Event;
import tresenraya.migii.userinterface.events.EventManager;
import tresenraya.migii.userinterface.events.NewPlayerEvent;
import tresenraya.migii.userinterface.events.SearchEvent;
import tresenraya.migii.userinterface.events.ShowFormEvent;
import tresenraya.migii.userinterface.events.UrlEvent;
import java.awt.event.ActionListener;
import javax.swing.JDialog;
import javax.swing.JOptionPane;

public class FormPlayerManager extends Anuncio implements IEventForm, ICambiable {

  private FormComponent formComponent;
  private FormSimple formSimple;
  private FormArcade formArcade;
  private FormModerno formModerno;
  private JDialog dialog;
  private DataBase dataBase = DataBase.getInstance();

  FormPlayerManager() {
    dialog = new JDialog();
    dialog.setTitle("Bienvenido a la dimension Gamer");
    dialog.setSize(300,300);
    createListener();
    this.formSimple = new FormSimple();
    this.formArcade = new FormArcade();
    this.formModerno = new FormModerno();
    this.formComponent = this.formSimple;
  }

  private void createListener() {
    EventManager eventManager = EventManager.getInstance();
    SearchEvent searchEvent = new SearchEvent();
    CancelFormEvent cancelFormEvent = new CancelFormEvent();
    ShowFormEvent showFormEvent = new ShowFormEvent();
    NewPlayerEvent newPlayerEvent = new NewPlayerEvent();
    searchEvent.comunicar(this);
    newPlayerEvent.comunicar(this);
    cancelFormEvent.comunicar(this);
    showFormEvent.comunicar(this);
    ActionListener actionListener = eventManager.getListener(Event.Url);
    if(actionListener instanceof UrlEvent){
      UrlEvent url = (UrlEvent) actionListener;
      url.comunicar(this);
    }
    eventManager.addListener(Event.SearchAlgorithm, searchEvent);
    eventManager.addListener(Event.OcultarFormDialogPlayer, cancelFormEvent);
    eventManager.addListener(Event.MostrarFormDialogPlayer, showFormEvent);
    eventManager.addListener(Event.NuevoJugador, newPlayerEvent);
  }

  @Override
  public void registrarJugador() {
    EventForm eventForm =  this.formComponent.getPlayerData();
    if(this.dataBase.existePlayer(eventForm.getNombre())){
      JOptionPane.showMessageDialog(formComponent, "EL ModelJugador ya existe", "Error al registrar modelJugador", JOptionPane.ERROR_MESSAGE);
    }else{
      if(eventForm.getFicha() == TipoFicha.Cruz){
        notifyJugadorX(eventForm);
      }else{
        notifyJugadorO(eventForm);
      }
      notifyRestartGame();
      dialog.setVisible(false);
    }
  }

  @Override
  public void searchEstrategia() {
    this.formComponent.openFileChooser();
  }

  @Override
  public void mostrarForm() {
    this.formComponent.cleanFields();
    dialog.add(formComponent);
    dialog.setVisible(true);
  }

  @Override
  public void cancelForm() {
    dialog.add(formComponent);
    dialog.setVisible(false);
  }

  @Override
  public void changeView(String view) {
    if(Tablero.Default.toString().equals(view))
      this.formComponent = this.formSimple;
    if (Tablero.Arcade.toString().equals(view))
      this.formComponent = this.formArcade;
    if (Tablero.Moderno.toString().equals(view))
      this.formComponent = this.formModerno;
  }

}
