package tresenraya.migii.listener.componentmanager;

import tresenraya.Posicion;
import tresenraya.migii.listener.interfaces.ICambiable;
import tresenraya.migii.logicadenegocio.jugador.implemetations.Bot;
import tresenraya.migii.logicadenegocio.tablero.implemetations.TipoFicha;
import tresenraya.migii.persistencia.ModelJugador;
import tresenraya.migii.listener.Anuncio;
import tresenraya.migii.listener.interfaces.IEventJoystick;
import tresenraya.migii.persistencia.DataBase;
import tresenraya.migii.userinterface.components.boardgame.Tablero;
import tresenraya.migii.userinterface.components.formplayer.EventForm;
import tresenraya.migii.library.Utils;
import tresenraya.migii.logicadenegocio.juego.implemetations.TresEnRaya;
import tresenraya.migii.userinterface.components.joystick.Joystick2;
import tresenraya.migii.userinterface.components.joystick.JoystickArcade;
import tresenraya.migii.userinterface.components.joystick.JoystickComponent;
import tresenraya.migii.userinterface.components.joystick.JoystickDefault;
import tresenraya.migii.userinterface.events.CheckEvent;
import tresenraya.migii.userinterface.events.Event;
import tresenraya.migii.userinterface.events.EventManager;
import tresenraya.migii.userinterface.events.JoystickEvent;
import java.io.File;
import java.io.IOException;
import tresenraya.migii.userinterface.events.UrlEvent;

public class JoystickManager extends Anuncio implements IEventJoystick, ICambiable {

  private TresEnRaya tresEnRaya;
  private DataBase dataBase = DataBase.getInstance();
  private JoystickComponent joystickComponent;
  private File file;
  private JoystickDefault joystickDefault;
  private JoystickArcade joystickArcade;
  private Joystick2 joystick2;
  private Bot botX;
  private Bot botO;
  private ModelJugador dataX;
  private ModelJugador dataO;

  JoystickManager(TresEnRaya tresEnRaya){
    file = new File(Utils.DIRECCION_DATABASE);
    this.tresEnRaya = tresEnRaya;
    createListener();
    initPlayerDefault();
    initJoystick();
  }

  private void initPlayerDefault() {
    ModelJugador modelJugadorHumano = dataBase.getJugador(Utils.NAME_DEFAULT);
    ModelJugador modelJugadorComputadora = dataBase.getJugador(Utils.NAME_MACHINE);
    if (modelJugadorHumano == null){
      modelJugadorHumano = new ModelJugador(Utils.NAME_DEFAULT);
    }
    if(modelJugadorComputadora == null){
      modelJugadorComputadora = new ModelJugador(Utils.NAME_MACHINE);
      modelJugadorComputadora.setFicha(TipoFicha.Circulo);
    }
    dataX = modelJugadorHumano;
    dataO = modelJugadorComputadora;
    this.botX = new Bot();
    this.botO = new Bot();
  }

  private void initJoystick() {
    this.joystickDefault = new JoystickDefault(this, this.botO);
    this.joystickArcade = new JoystickArcade(this, this.botX, this.botO);
    this.joystick2 = new Joystick2(this, this.botX, this.botO);
    this.joystickComponent = this.joystickDefault;
  }

  private void createListener() {
    EventManager eventManager = EventManager.getInstance();
    CheckEvent checkEvent = new CheckEvent();
    JoystickEvent joystickEvent = new JoystickEvent();
    checkEvent.comunicar(this);
    joystickEvent.comunicar(this);
    eventManager.addListener(Event.MarcarTablero, checkEvent);
    eventManager.addListener(Event.Joystick, joystickEvent);
    UrlEvent urlEvent = (UrlEvent) eventManager.getListener(Event.Url);
    urlEvent.comunicar(this);
  }

  @Override
  public void changeJoystick(String actionCommand) {
    Posicion escalar = this.joystickComponent.updateCasilla(actionCommand);
    notifyMovimientoPuntero(new Posicion(Utils.CENTER_FIRST_CELL_X+escalar.fila,Utils.CENTER_FIRST_CELL_Y+escalar.columna)
        ,TipoFicha.Marca.toString());
  }

  @Override
  public void jugar(Posicion posicion) {
    this.joystickComponent.jugar(posicion);
  }

  public boolean jugarX(Posicion posicion){
    boolean jugadaCorrecta = false;
    if(this.tresEnRaya.esTurnoX()){
      tresEnRaya.hacerJugadaX(posicion);
      if(!this.tresEnRaya.esTurnoX()){
        notifyJugada(posicion, "X");
        jugadaCorrecta = true;
        checkStatus();
      } else
        notifyCasillaOcupada();
    }
    return jugadaCorrecta;
  }

  public boolean jugarO(Posicion posicion) {
    boolean jugadaCorrecta = false;
    if(!this.tresEnRaya.esTurnoX()){
      tresEnRaya.hacerJugadaO(posicion);
      if(this.tresEnRaya.esTurnoX()){
        notifyJugada(posicion, "O");
        checkStatus();
        jugadaCorrecta = true;
      } else
        notifyCasillaOcupada();
    }
    return jugadaCorrecta;
  }

  private void checkStatus() {
    if (this.tresEnRaya.terminado()){
      char winner = this.tresEnRaya.obtenerGanador();
      switch (winner){
        case 'X':
          this.dataX.increaseVictories();
          savePlayer(this.dataX);
          notifyUpdate();
          notifyGanador(this.dataX);
          break;
        case 'O':
          this.dataO.increaseVictories();
          notifyUpdate();
          savePlayer(this.dataO);
          notifyGanador(this.dataO);
          break;
        case '\0':
          notifyEmpate();
          break;
      }
    }
  }

  @Override
  public void cargarJugadorX(EventForm eventForm){
    this.dataX = this.joystickComponent.crearJugadorX(eventForm);
    savePlayer(this.dataX);
  }

  @Override
  public void cargarJugadorO(EventForm eventForm){
    this.dataO = this.joystickComponent.crearJugadorO(eventForm);
    savePlayer(this.dataO);
  }

  private void savePlayer(ModelJugador modelJugador){
    if(this.dataBase.existePlayer(modelJugador.getNombre())){
      dataBase.removePlayer(modelJugador.getNombre());
    }
    try {
      dataBase.addJugador(modelJugador);
      dataBase.saveToFile(file);
    } catch (IOException e) {
      System.err.println("Cambiaste de Clase ModelJugador");
    }
  }

  JoystickComponent getComponent() {
    return this.joystickComponent;
  }

  @Override
  public void changeView(String command) {
    if(Tablero.Default.toString().equals(command))
      this.joystickComponent = this.joystickDefault;
    if (Tablero.Arcade.toString().equals(command))
      this.joystickComponent = this.joystickArcade;
    if (Tablero.Moderno.toString().equals(command))
      this.joystickComponent = this.joystick2;
  }

  void restartBots() {
    this.botX.reiniciarJuego();
    this.botO.reiniciarJuego();
  }

}

