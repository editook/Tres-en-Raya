package tresenraya.migii.listener.componentmanager;

import tresenraya.migii.listener.interfaces.ICambiable;
import tresenraya.migii.listener.interfaces.IEventGame;
import tresenraya.migii.userinterface.components.boardgame.TableroComponent;
import tresenraya.migii.userinterface.components.joystick.JoystickComponent;
import tresenraya.migii.userinterface.components.frame.MainFrame3;
import tresenraya.migii.userinterface.MyGame;
import tresenraya.migii.userinterface.components.frame.MainFrame2;
import tresenraya.migii.logicadenegocio.juego.implemetations.TresEnRaya;
import tresenraya.migii.userinterface.components.frame.MainFrame;
import tresenraya.migii.userinterface.components.tableplayer.TablePlayerComponent;
import tresenraya.migii.userinterface.components.boardgame.Tablero;
import tresenraya.migii.userinterface.components.frame.FrameComponent;
import tresenraya.migii.userinterface.events.Event;
import tresenraya.migii.userinterface.events.EventManager;
import tresenraya.migii.userinterface.events.ExitEvent;
import tresenraya.migii.userinterface.events.NewGameEvent;
import tresenraya.migii.userinterface.events.UrlEvent;
import java.awt.BorderLayout;
import java.awt.MenuBar;

public class FrameManager implements IEventGame, ICambiable {

  private TresEnRaya tresEnRaya;
  private MyGame myGame;
  private FrameComponent frame;
  private MenuManager menuManager;
  private BoardManager boardManager;
  private JoystickManager joystickManager;
  private UrlEvent  urlEvent;
  private TablePlayerManager tablePlayerManager;

  public FrameManager(MyGame myGame, TresEnRaya tresEnRaya){
    this.tresEnRaya = tresEnRaya;
    this.myGame = myGame;
    createListeners();
    createManagerComponents();
    changeView(Tablero.Default.toString());
  }

  private void createManagerComponents() {
    NotificadorManager notificadorManager = new NotificadorManager(myGame);
    FormPlayerManager formPlayerManager = new FormPlayerManager();
    tablePlayerManager = new TablePlayerManager();
    menuManager = new MenuManager();
    joystickManager = new JoystickManager(tresEnRaya);
    boardManager = new BoardManager(tresEnRaya);
    joystickManager.comunicar(boardManager);
    joystickManager.comunicar(notificadorManager);
    joystickManager.comunicar(tablePlayerManager);
    notificadorManager.comunicar(this);
    formPlayerManager.comunicar(this);
    formPlayerManager.comunicar(joystickManager);
    menuManager.comunicar(notificadorManager);
    urlEvent.comunicar(this);
  }

  private void createListeners() {
    EventManager eventManager = EventManager.getInstance();
    NewGameEvent newGameEvent = new NewGameEvent();
    ExitEvent exitEvent = new ExitEvent();
    urlEvent = new UrlEvent();
    newGameEvent.comunicar(this);
    exitEvent.comunicar(this);
    eventManager.addListener(Event.Url, urlEvent);
    eventManager.addListener(Event.NewGame, newGameEvent);
    eventManager.addListener(Event.Exit, exitEvent);
  }

  @Override
  public void salirJuego() {
    this.frame.exit();
  }

  @Override
  public void restartGame() {
    this.tresEnRaya.reiniciarJuego();
    boardManager.setNewTablero(this.tresEnRaya.toString());
    this.joystickManager.restartBots();
  }

  @Override
  public void setNewGame() {
    this.tresEnRaya.reiniciarJuego();
    boardManager.setNewGame();
  }

  @Override
  public void changeView(String command) {
    if(this.frame != null)
      this.frame.dispose();
    MenuBar menuBar = this.menuManager.getMenuBar();
    if(Tablero.Default.toString().equals(command))
      createViewDefault();
    if (Tablero.Arcade.toString().equals(command))
      createViewArcade();
    if (Tablero.Moderno.toString().equals(command))
      createViewModerno();
    this.frame.setMenuBar(menuBar);
    this.frame.setVisible(true);
  }

  private void createViewDefault(){
    TableroComponent tableroComponent = this.boardManager.getComponent();
    this.frame = new MainFrame();
    this.frame.getContentPane().add(tableroComponent,BorderLayout.CENTER);
    this.frame.pack();
  }

  private void createViewArcade(){
    TableroComponent tableroComponent = this.boardManager.getComponent();
    JoystickComponent joystickComponent = this.joystickManager.getComponent();
    this.frame = new MainFrame2();
    TablePlayerComponent tablePlayerComponent = this.myGame.getTablePlayer();
    ((MainFrame2) this.frame).setComponents(tablePlayerComponent, tableroComponent,
        joystickComponent);
  }

  private void createViewModerno() {
    TableroComponent tableroComponent = this.boardManager.getComponent();
    this.frame = new MainFrame3();
    TablePlayerComponent tablePlayerComponent = this.tablePlayerManager.getTablePlayer();
    JoystickComponent joystickComponent = this.joystickManager.getComponent();
    ((MainFrame3) this.frame).setComponents(tableroComponent, tablePlayerComponent,joystickComponent);
  }

}
