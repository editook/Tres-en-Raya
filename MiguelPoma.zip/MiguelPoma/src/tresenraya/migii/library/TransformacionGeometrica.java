package tresenraya.migii.library;

import tresenraya.Posicion;

public class TransformacionGeometrica {

  public static Posicion transformar2D(int index){
    int filas = index/3;
    int columnas = index%3;
    return new Posicion(filas,columnas);
  }

  public static int transformar1D(int x, int y){
    return (x*3)+y ;
  }

  public static Posicion escalar(int x, int y, int tam){
    int posx = x*tam;
    int posy = y*tam;
    return new Posicion(posx, posy);
  }

}
