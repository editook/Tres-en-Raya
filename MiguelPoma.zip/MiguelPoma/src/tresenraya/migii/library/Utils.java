package tresenraya.migii.library;

import java.io.File;
import java.net.MalformedURLException;
import javax.swing.*;
import java.net.URL;

public class Utils {

  public static final int DISTACIA_CASILLA = 100;
  public static final int CENTER_FIRST_CELL_X = 0;
  public static final int CENTER_FIRST_CELL_Y = 0;
  public static final int ROWS_TRES_EN_RAYA = 3;
  public static final int COLUMNS_TRES_EN_RAYA = 3;
  public static final String NAME_DEFAULT = "Anonimo";
  public static final String MENSAJE_ABOUT = "This simple game is created by \nMigi.";
  public static final String NOMBRE_JUEGO = "Tic Tac Toe";
  public static final String NAME_MACHINE = "Computadora";
  public static final String DIRECCION_DATABASE = "src/tresenraya/migii/persistencia/database.per";

  @Deprecated
  public static ImageIcon createIcon(File file) throws MalformedURLException {
    URL url = file.toURI().toURL();
    if(url == null) {
      System.err.println("Unable to load image: " + file.getPath());
    }
    ImageIcon icon = new ImageIcon(url);
    return icon;
  }

  public static String getFileExtension(String name) {
    String respuesta = null;
    int pointIndex = name.lastIndexOf(".");

    if(pointIndex != -1 && pointIndex != name.length()-1) {
      respuesta = name.substring(pointIndex+1, name.length());
    }

    return respuesta;
  }

}
