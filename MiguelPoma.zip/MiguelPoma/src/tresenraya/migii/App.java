package tresenraya.migii;

import tresenraya.migii.userinterface.MyGame;
import tresenraya.migii.logicadenegocio.juego.implemetations.TresEnRaya;

public class App {

  public static void main(String[] args) {
    TresEnRaya tresEnRaya = new TresEnRaya();
    new MyGame(tresEnRaya);
  }

}