package tresenraya.migii.logicadenegocio.jugador.interfaces;

import tresenraya.Posicion;

public interface IngenioJugador {

  Posicion hacerJugada();

}
