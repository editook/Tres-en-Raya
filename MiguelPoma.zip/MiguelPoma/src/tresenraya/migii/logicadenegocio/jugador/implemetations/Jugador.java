package tresenraya.migii.logicadenegocio.jugador.implemetations;

public class Jugador {

  private String nombre;

  public Jugador(String nombre){
    this.nombre = nombre;
  }

}
