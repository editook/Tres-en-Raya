package tresenraya.migii.logicadenegocio.jugador.implemetations;

import tresenraya.Posicion;
import tresenraya.migii.logicadenegocio.jugador.interfaces.IngenioJugador;
import estrategia.Estrategia;

public class Bot implements IngenioJugador {

  private Estrategia estrategia;
  private boolean activo;

  public Bot(){
    estrategia = new AlgorithmDefault();
    activo = false;
  }

  public void cambiarIngenio(Class algorithm){
    try {
      estrategia = (Estrategia) algorithm.newInstance();
    } catch (InstantiationException ie) {   // No se puede instanciar la clase
      ie.printStackTrace();
    } catch (IllegalAccessException iae) {  // No se puede acceder a la instancia
      iae.printStackTrace();
    }
  }

  @Override
  public Posicion hacerJugada() {
    return estrategia.hacerJugada();
  }

  public void registrarJugada(Posicion posicion){
    this.estrategia.registrarJugadaContraria(posicion);
  }

  public void reiniciarJuego(){
    this.estrategia.reiniciarJuego();
  }

  public boolean estaActivo(){
    return activo;
  }

  public void activar(boolean estado){
    this.activo = estado;
  }

}
