package tresenraya.migii.logicadenegocio.reglas.implemetations;

import tresenraya.migii.logicadenegocio.reglas.interfaces.IRegla;

public class NumeroJugada implements IRegla {

  private int jugada;

  public NumeroJugada(int cantidadJugadas){
    jugada = cantidadJugadas;
  }

  @Override
  public boolean cumple() {
    boolean respuesta;
    respuesta = jugada != 0;
    return respuesta;
  }

  public void setChange(){
    jugada--;
  }

}
