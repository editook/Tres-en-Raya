package tresenraya.migii.logicadenegocio.reglas.implemetations;

import tresenraya.migii.logicadenegocio.reglas.interfaces.IRegla;
import tresenraya.migii.logicadenegocio.tablero.implemetations.Casilla;
import tresenraya.migii.logicadenegocio.tablero.interfaces.ITablero;

public class CasillaValida implements IRegla {

  private ITablero tablero;
  private Casilla casilla;
  private boolean cambio;

  @Override
  public boolean cumple() {
    boolean respuesta;
    boolean filaValida;
    boolean columnaValida;
    if(cambio){
      if (tablero != null && casilla != null){
        filaValida = casilla.getFila() >= 0 && casilla.getFila() < tablero.getFilas();
        columnaValida = casilla.getColumna() >= 0 && casilla.getColumna() < tablero.getColumnas();
        respuesta = filaValida && columnaValida;
        cambio = false;
      }else {
        respuesta = false;
      }
    }else {
      respuesta = false;
    }
    return respuesta;
  }

  public void setChange(ITablero tablero, Casilla casilla){
    cambio = true;
    this.tablero = tablero;
    this.casilla = casilla;
  }

}
