package tresenraya.migii.logicadenegocio.reglas.implemetations;

import tresenraya.migii.logicadenegocio.reglas.interfaces.IRegla;
import tresenraya.migii.logicadenegocio.tablero.implemetations.Casilla;
import tresenraya.migii.logicadenegocio.tablero.interfaces.ITablero;

public class CasillaVacia implements IRegla {

  private ITablero tablero;
  private Casilla casilla;
  private boolean cambio = false;
  private CasillaValida casillaValida = new CasillaValida();

  public CasillaVacia(ITablero tablero){
    this.tablero = tablero;
  }

  @Override
  public boolean cumple() {
    boolean respuesta;
    if(cambio){
      casillaValida.setChange(tablero,casilla);
      if(casillaValida.cumple()){
        respuesta = tablero.getCasilla(casilla.getFila(), casilla.getColumna()).estaVacia();
      }else {
        respuesta = false;
      }
      cambio = false;
    }else{
      respuesta = false;
    }
    return respuesta;
  }

  public void setChange(Casilla casilla){
    if (casilla != null){
      cambio = true;
    }
    this.casilla = casilla;
  }

}
