package tresenraya.migii.logicadenegocio.reglas.implemetations;

import tresenraya.migii.logicadenegocio.reglas.interfaces.IRegla;
import tresenraya.migii.logicadenegocio.tablero.implemetations.Casilla;
import tresenraya.migii.logicadenegocio.tablero.interfaces.ITablero;

public class TresEnRayaValida implements IRegla {

  private ITablero tablero;
  private Casilla casillaMarcar;
  private CasillaValida casillaValida = new CasillaValida();
  private boolean cambio = false;

  public TresEnRayaValida(ITablero tablero){
    this.tablero = tablero;
  }

  public void setChange(Casilla casilla) {
    this.casillaMarcar = casilla;
    casillaValida.setChange(tablero,casilla);
    if (casillaValida.cumple())
      cambio = true;
    else
      cambio = false;
  }

  private boolean verificarFilaGanadora() {
    boolean iguales = true;
    int fila = casillaMarcar.getFila();
    Casilla casilla ;
    for(int j = 0; j < tablero.getColumnas() && iguales; j++){
      casilla = this.tablero.getCasilla(fila,j);
      iguales = casilla.equals(casillaMarcar);
    }
    return iguales;
  }

  private boolean verificarColumnaGanadora() {
    boolean iguales = true;
    int columna = casillaMarcar.getColumna();
    Casilla casilla ;
    for(int i = 0; i < tablero.getFilas() && iguales; i++){
      casilla = tablero.getCasilla(i,columna);
      iguales = casilla.equals(casillaMarcar);
    }
    return iguales;
  }

  private boolean verificarDiagonales() {
    boolean iguales = true;
    Casilla casilla;

    for(int i = 0; i < tablero.getFilas() && iguales; i++){
      casilla = this.tablero.getCasilla(i,i);
      iguales = casilla.equals(casillaMarcar);
    }

    if(!iguales) {
      iguales = true;
      for (int j = 0; j < tablero.getColumnas() && iguales; j++) {
        casilla = this.tablero.getCasilla(j, tablero.getColumnas() - j - 1);
        iguales = casilla.equals(casillaMarcar);
      }
    }
    return iguales;
  }


  @Override
  public boolean cumple() {
    boolean respuesta;
    if(cambio){
      respuesta = (verificarFilaGanadora() || verificarColumnaGanadora() || verificarDiagonales());
    }else{
      respuesta = false;
    }
    return respuesta;
  }

}
