package tresenraya.migii.logicadenegocio.reglas.interfaces;

public interface IRegla {
  boolean cumple();
}
