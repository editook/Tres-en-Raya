package tresenraya.migii.logicadenegocio.tablero.interfaces;

import tresenraya.migii.logicadenegocio.tablero.implemetations.Casilla;

public interface ITablero {

  void inicializarTablero();
  void marcarCasilla(Casilla casilla) ;
  Casilla getCasilla(int x, int y);
  int getColumnas();
  int getFilas();

}
