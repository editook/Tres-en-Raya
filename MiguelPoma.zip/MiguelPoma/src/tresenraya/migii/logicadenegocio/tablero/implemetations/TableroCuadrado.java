package tresenraya.migii.logicadenegocio.tablero.implemetations;

import tresenraya.migii.logicadenegocio.tablero.interfaces.ITablero;

public class TableroCuadrado implements ITablero {

  private Casilla[][] tablero;
  private int filas,columnas;
  private Casilla.Builder builder = new Casilla.Builder();

  public TableroCuadrado(int filas, int columnas){
    this.filas = filas;
    this.columnas = columnas;
    tablero =  new Casilla[filas][columnas];
    inicializarTablero();
  }

  @Override
  public void inicializarTablero() {
    for (int i = 0; i < filas; i++)
      for(int j = 0; j < columnas; j++){
        builder.posicion(i,j);
        tablero[i][j] = builder.build();
      }
  }

  @Override
  public void marcarCasilla(Casilla casilla) {
    tablero[casilla.getFila()][casilla.getColumna()] = casilla;
  }

  public Casilla getCasilla(int x, int y) {
    return tablero[x][y];
  }

  @Override
  public int getColumnas() {
    return filas;
  }

  @Override
  public int getFilas() {
    return columnas;
  }

  @Override
  public String toString(){
    StringBuilder sb = new StringBuilder();
    for (int i = 0; i < filas; i++){
      for(int j = 0; j < columnas; j++)
        sb.append(tablero[i][j].toString());

    }
    return sb.toString();
  }


}
