package tresenraya.migii.logicadenegocio.tablero.implemetations;

public enum TipoFicha {
  Cruz{
    @Override
    public String toString(){
      return "X";
    }
  },
  Circulo{
    @Override
    public String toString(){
      return "O";
    }
  },
  Marca{
    @Override
    public String toString(){
      return "º";
    }
  }
}
