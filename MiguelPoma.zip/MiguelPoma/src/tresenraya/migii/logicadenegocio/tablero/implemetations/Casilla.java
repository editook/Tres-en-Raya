package tresenraya.migii.logicadenegocio.tablero.implemetations;

public class Casilla {

  private final TipoFicha ficha;
  private final boolean estaVacio;
  private final int x;
  private final int y;

  public static class Builder{
    private TipoFicha ficha;
    private int x;
    private int y;
    private boolean estaVacio = true;

    public Casilla build(){
      return new Casilla(this);
    }

    public Builder ficha(TipoFicha ficha){
      this.ficha = ficha;
      estaVacio = false;
      return this;
    }

    public Builder posicion(int x, int y){
      this.x = x;
      this.y = y;
      return this;
    }

  }

  public Casilla (Builder builder){
    this.ficha = builder.ficha;
    this.x = builder.x;
    this.y = builder.y;
    this.estaVacio = builder.estaVacio;
  }

  public boolean estaVacia() {
    return estaVacio;
  }

  public int getFila(){
    return x;
  }

  public int getColumna(){
    return y;
  }

  public TipoFicha obtenerFicha() {
    return this.ficha;
  }

  @Override
  public boolean equals(Object object){
    boolean son_iguales = false;
    if(object == null)
      son_iguales = false;

    if (!Casilla.class.isAssignableFrom(object.getClass()))
      son_iguales = false;

    Casilla casilla = (Casilla)object;
    if (this.ficha == ((Casilla) object).ficha )
      son_iguales = true;
    return son_iguales;
  }

  @Override
  public String  toString(){
    StringBuilder sb = new StringBuilder();
    if(this.ficha != null){
      sb.append(this.ficha.toString());
    } else {
      sb.append(" ");
    }
    return sb.toString();
  }

}
