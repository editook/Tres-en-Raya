package tresenraya.migii.logicadenegocio.juego.interfaces;

import tresenraya.Posicion;

public interface ITresEnRaya {

  void hacerJugadaX(Posicion posicion);
  void hacerJugadaO(Posicion posicion);
  boolean terminado();
  char obtenerGanador();
  void reiniciarJuego();
  boolean esTurnoX();

}
