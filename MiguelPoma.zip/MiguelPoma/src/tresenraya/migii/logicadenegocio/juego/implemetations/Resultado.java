package tresenraya.migii.logicadenegocio.juego.implemetations;

public enum Resultado {
  ganadorCruz,
  ganadorCirculo,
  empate
}
