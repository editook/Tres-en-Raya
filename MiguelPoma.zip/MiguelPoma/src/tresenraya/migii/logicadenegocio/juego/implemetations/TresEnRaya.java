package tresenraya.migii.logicadenegocio.juego.implemetations;

import tresenraya.migii.logicadenegocio.juego.interfaces.ITresEnRaya;
import tresenraya.migii.logicadenegocio.reglas.implemetations.CasillaVacia;
import tresenraya.migii.logicadenegocio.reglas.implemetations.NumeroJugada;
import tresenraya.migii.logicadenegocio.reglas.implemetations.TresEnRayaValida;
import tresenraya.migii.logicadenegocio.tablero.implemetations.Casilla;
import tresenraya.Posicion;
import tresenraya.migii.logicadenegocio.tablero.implemetations.TipoFicha;
import tresenraya.migii.logicadenegocio.tablero.implemetations.TableroCuadrado;
import tresenraya.migii.logicadenegocio.tablero.interfaces.ITablero;

public class TresEnRaya implements ITresEnRaya {

  private ITablero tablero;
  private Resultado resultadoJuego = Resultado.empate;
  private int turno;
  private CasillaVacia casillaVacia;
  private NumeroJugada numeroJugada;
  private TresEnRayaValida validadorUnaRaya;

  public TresEnRaya() {
    initReglasJuego();
  }

  private void initReglasJuego() {
    turno = 0;
    tablero = new TableroCuadrado(3,3);
    casillaVacia = new CasillaVacia(tablero);
    validadorUnaRaya = new TresEnRayaValida(tablero);
    numeroJugada = new NumeroJugada(9);
  }

  @Override
  public void hacerJugadaX(Posicion posicion) {
    Casilla.Builder builder = new Casilla.Builder();
    if(turno == 0){
      builder.posicion(posicion.fila,posicion.columna).ficha(TipoFicha.Cruz);
      actualizar(builder.build());
    }
  }

  @Override
  public void hacerJugadaO(Posicion posicion) {
    Casilla.Builder builder = new Casilla.Builder();
    if(turno == 1){
      builder.posicion(posicion.fila,posicion.columna).ficha(TipoFicha.Circulo);
      actualizar(builder.build());
    }
  }

  @Override
  public boolean terminado() {
    return Resultado.empate != resultadoJuego || !numeroJugada.cumple();
  }

  @Override
  public char obtenerGanador() {
    return resultadoJuego == Resultado.ganadorCruz ? 'X' :
        resultadoJuego == Resultado.ganadorCirculo ? 'O' :
            resultadoJuego == Resultado.empate && terminado() ? '\0' : '-' ;
  }

  @Override
  public void reiniciarJuego() {
    initReglasJuego();
    turno = resultadoJuego == Resultado.empate ? 0 :
        resultadoJuego == Resultado.ganadorCruz ? 1 : 0;
    resultadoJuego = Resultado.empate;
  }

  @Override
  public  boolean esTurnoX(){
    boolean respuesta = false;
    if(turno == 0){
      respuesta = true;
    }
    return respuesta;
  }

  private void cambiarTurno(){
    turno = (turno+1)%2;
  }

  private void actualizar(Casilla casilla) {
    casillaVacia.setChange(casilla);
    if (casillaVacia.cumple()) {
      this.tablero.marcarCasilla(casilla);
      numeroJugada.setChange();
      validadorUnaRaya.setChange(casilla);
      checkGameStatus(casilla);
      cambiarTurno();
    }
  }

  private void checkGameStatus(Casilla casilla){
    if(validadorUnaRaya.cumple()){
      resultadoJuego = casilla.obtenerFicha() == TipoFicha.Cruz ?
          Resultado.ganadorCruz : Resultado.ganadorCirculo;
    }
  }

  @Override
  public String toString(){
    return this.tablero.toString();
  }

}
