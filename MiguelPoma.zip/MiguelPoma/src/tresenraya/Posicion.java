package tresenraya;

public class Posicion {

  public int fila;
  public int columna;

  public Posicion(int fila, int columna){
    this.fila = fila;
    this.columna = columna;
  }

}
