
import estrategia.Estrategia;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import tresenraya.Posicion;

public class Main {

  private JFileChooser fileChooser;
  private Class algorithm;

  public static void main(String[] args) {
    Main main = new Main();
    /*
    ClassLoader classLoader = Main.class.getClassLoader();
    try {
      Class eClass = classLoader.loadClass("estrategia.Aleatoria");
      Estrategia e = (Estrategia) eClass.newInstance();
      Posicion p = e.hacerJugada();
      System.out.println(p.fila);
    } catch (ClassNotFoundException cnfe) { // No encuentra la clase
      cnfe.printStackTrace();
    } catch (InstantiationException ie) {   // No se puede instanciar la clase
      ie.printStackTrace();
    } catch (IllegalAccessException iae) {  // No se puede acceder a la instancia
      iae.printStackTrace();
    }*/

    main.openFileChooser();
    main.execute();
  }

  public void execute(){
    try {
      Estrategia e = (Estrategia) algorithm.newInstance();
      Posicion p = e.hacerJugada();
      System.out.println(p.fila);
    } catch (InstantiationException ie) {   // No se puede instanciar la clase
      ie.printStackTrace();
    } catch (IllegalAccessException iae) {  // No se puede acceder a la instancia
      iae.printStackTrace();
    }
  }

  public void openFileChooser() {
    String nameFile, myPackege;
    JFrame frame = new JFrame();
    frame.setSize(100,100);
    frame.setVisible(true);
    fileChooser = new JFileChooser();
    if(fileChooser.showOpenDialog(frame) == JFileChooser.APPROVE_OPTION){
      File file = fileChooser.getSelectedFile().getParentFile();
      nameFile = fileChooser.getSelectedFile().getName();
      try {
        System.out.println(file.toURI().toURL().toString());
        URLClassLoader loader = new URLClassLoader(new URL[]{ new URL(file.toURI().toURL().toString()) });
        myPackege = "estrategia."+nameFile.substring(0,nameFile.lastIndexOf("."));
        algorithm = loader.loadClass(myPackege );
      } catch (MalformedURLException ignored) {
      } catch (ClassNotFoundException e) {
        e.printStackTrace();
      }
    }
  }

}
